package dao;

public class DynamoDB_dao {

}
