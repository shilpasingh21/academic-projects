package dao;

public class sns_dao {

}
