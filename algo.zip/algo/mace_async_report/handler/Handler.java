package DP;

/** You are climbing a staircase. It takes n steps to reach the top.
 *  Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?
 */

public class Handler {
	
/** 1. read the event and map it to an event object.
	
	2. This event object is then passed to the event processor.
	
	3. Event processor will then get the identity information.
	
	4. Then it will validate the filters 
	
	5. It will generate a query id and store the payload in a DDB table with status requested.
	
    6. It will add the request payload to the sqs event queue.
    
    7. It will send the response back to the front end. */
	
	
	
	
	
}
