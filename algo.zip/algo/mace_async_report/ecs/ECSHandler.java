package ecs;

public class ECSHandler {
	
	/*  instantiate Redshift DAO
	 *  query Redshift and write the output to S3.
	 * Update dynamodb with the query status .
	 * If there are any failures, update it with the failed status.*/
	 
	
	
	
	

}
