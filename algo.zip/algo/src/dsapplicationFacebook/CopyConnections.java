package dsapplicationFacebook;

import java.util.*;

/* Clone graph */

/* 0 --> 3,2,4

1-> 4,2

2 -->_ 3, 1, 0

3 --> 0, 4, 2

4 --> 0, 3, 1*/

public class CopyConnections {

	static List<LinkedList<Integer>> adjList = new ArrayList<LinkedList<Integer>>();

	static List<LinkedList<Integer>> clonedadjList = new ArrayList<LinkedList<Integer>>();

	public static void main(String[] args) {

		LinkedList<Integer> list1 = new LinkedList<Integer>();

		list1.add(3);

		list1.add(2);

		list1.add(4);

		adjList.add(list1);

		LinkedList<Integer> list2 = new LinkedList<Integer>();

		list2.add(4);

		list2.add(2);

		adjList.add(list2);

		LinkedList<Integer> list3 = new LinkedList<Integer>();

		list3.add(3);

		list3.add(1);

		list3.add(0);

		adjList.add(list3);

		LinkedList<Integer> list4 = new LinkedList<Integer>();

		list4.add(0);

		list4.add(4);

		list4.add(2);

		adjList.add(list4);

		LinkedList<Integer> list5 = new LinkedList<Integer>();

		list4.add(0);

		list4.add(3);

		list4.add(1);

		adjList.add(list5);

	}
	
	
	public void clone() {
		
		Set<Integer> set = new HashSet<Integer>();
		
		Stack<Integer> stack = new Stack<Integer>();
		
		int startIndex = 0;
		
		stack.push(startIndex);
		
		while (!stack.isEmpty()) {
			
			Integer current = stack.pop();
			
			set.add(startIndex);
			
			LinkedList<Integer> list = adjList.get(current);
			
			Iterator<Integer> itr = list.iterator();
			
			while (itr.hasNext()){
				
				Integer next = itr.next();
				
				if(!set.contains(next)) {
					
					stack.push(next);
					
				}
			}
			
			
			
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	

}
