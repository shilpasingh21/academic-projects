package dsapplicationFacebook;

import java.util.*;

/* The Facebook Status API queues requests using the requested Status ID and a timestamp. We want to 
 * implement a throttling mechanism on the requests that limits one request for a particular Status ID at
 *  a pre-configured time interval. Any additional requests for the same Status ID in this interval will be dropped. 
 * Multiple requests for different Status IDs can occur at the same time.
 */

public class RequestLimiter {

	private HashMap<String, Integer> map;

	RequestLimiter() {

		map = new HashMap<String, Integer>();
	}

	public boolean acceptRequest(String requestId, Integer currentTime) {
		
		if(map.containsKey(requestId)) {
			
			Integer lastTime = map.get(requestId);
			
			if (currentTime - lastTime >=5) {
				
				map.put(requestId, currentTime);
				
				return true;
			}
			
			else {
				
				return false;
			}
		}
		
		else {
			
			map.put(requestId, currentTime);
			
			return true;
		}
	}
	
	
	public static void main(String[] args) {
		
		RequestLimiter limiter = new RequestLimiter();
		
		System.out.println(limiter.acceptRequest("id1", 1));
		
		System.out.println(limiter.acceptRequest("id2", 1));
		
		System.out.println(limiter.acceptRequest("id1", 2));
		
		System.out.println(limiter.acceptRequest("id1", 8));
		
		
	}
			
			
			
				
				
				
				
				
				
			
			
		
			
			
			
			
			
			
			
			
		
		
		
		
		
		
		
	

}
