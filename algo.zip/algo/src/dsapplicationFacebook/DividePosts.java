package dsapplicationFacebook;

import java.util.*;

// 1000, 2000, 3000, 4000, 5000; k =3;

public class DividePosts {
	
	
	public static int dividePosts(int[] days, int k) {
		
		int left =1; 
		
		int right = Arrays.stream(days).sum() / k;
		
		while(left<right) {
			
			
			
			
		}
		
		
		
		
		
		
	}

}
