import java.util.*;

public class MergeKLists {

    public static void main(String[] args) {

        int[][] input = new int[][]{{1,2,3},{4,5,6},{7,8,9}};

        List<ArrayList<Integer>> inputList = new ArrayList<>();
        Map<Integer,Integer> map = new HashMap<Integer, Integer>();

        PriorityQueue<Integer> queue = new PriorityQueue<>();

        List<Integer> output = new ArrayList<Integer>();

        for(int i=0; i<input.length; i++) {

            ArrayList<Integer> temp = new ArrayList<>();
            for (int intVal : input[i]) {
                temp.add(intVal);
            }

            inputList.add(temp);
            map.put(input[i][0], i);
            queue.add(input[i][0]);
        }

        while (!queue.isEmpty()) {

           Integer min =  queue.poll();

           output.add(min);

           Integer listIndex = map.get(min);

            inputList.get(listIndex).remove(0);

            map.put(listIndex,)




























            


            




        }




    }
}
