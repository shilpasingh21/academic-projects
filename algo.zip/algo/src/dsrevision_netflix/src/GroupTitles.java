import java.util.*;


public class GroupTitles {

    static Map<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

    public static void main(String[] args) {

        String[] input = new String[] {"duel", "dule", "speed", "spede", "deul", "cars"};

        String key = "dule";

        for (String word: input) {
            store(word);
        }

        String sorted = sort(key);

        System.out.println("sorted:" + sorted);

        ArrayList<String> matchingWords = map.get(sorted);

        for(String word: matchingWords) {
            System.out.println(word);
        }

    }

    private static void store(String input) {

        String sorted = sort(input);

        if(map.containsKey(sorted)) {
            map.get(sorted).add(input);
        }

        else{
            ArrayList<String> words = new ArrayList<String>();
            words.add(input);
            map.put(sorted, words);
        }
    }


    private static String sort(String input) {

        char[] charword = input.toCharArray();
        Arrays.sort(charword);

        String sorted = String.valueOf(charword);

        return sorted;
    }


}
