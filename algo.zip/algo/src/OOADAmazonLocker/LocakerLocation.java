package OOADAmazonLocker;

public class LocakerLocation {
	
	latitue
	
	longitue;
	
	start time
	
	close tiem;

}
