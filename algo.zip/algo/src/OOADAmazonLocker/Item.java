package OOADAmazonLocker;

public class Item {
	
	private int itemid;
	
	private float quantity;
	
}
