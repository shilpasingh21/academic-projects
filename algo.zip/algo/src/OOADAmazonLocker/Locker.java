package OOADAmazonLocker;

public class Locker {
	
	locationId;
	
	locakerstae;
	
	lockerid;
	
	
	assignpackage(0)
	
	remocepackage()
	
	
	
	
	
	
	
	
	
	
	
	

}
