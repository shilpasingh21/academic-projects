package OOADAmazonLocker;

public class Order {
	
	List<Item> items;
	
	int orderid;
	
	Address shippingdress;
	
	
	
	
	
	
	
	
	
	
	
	

}
