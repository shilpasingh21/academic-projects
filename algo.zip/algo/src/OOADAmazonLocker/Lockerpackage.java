package OOADAmazonLocker;

public class LockerPackage {
	
	private int lockerid;
	
	private int lockerCode;
	
	private int packageId;
	
	private int codevalidays;
	
	private date delivertime;
	
	public iscodevalid() {
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
