package OOADAmazonLocker;

// Details are:

/*Items:There are items in an order. An item will have a quantity and item id. 
 * 
 * Oder: An orfer will have a list of items, order id and the shipping location.
 * 
 * Notfification: When an order is shipped a notfification is sent to the customer. 
 * The notification will havre order id, customerid, locker id, shippinh date, locker code.
 * 
 * 
 *Package: this will have the soze, package id and order id.
 *
 *LockerPacakge: Package dispatched fora locker will have locker code, lockerid, time when it is palced in the cocker,.
 *
 *Locker: it will have the location, size, and state 
 *
 *LockerLocaion: location details.
 *
 *Locker service:  List of locker location. */
 
 
 
