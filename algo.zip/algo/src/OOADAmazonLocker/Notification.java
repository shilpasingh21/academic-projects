package OOADAmazonLocker;

public class Notification {
	
	customerid
	
	orderid
	
	lockerid
	
	lockercode
	
	shippingdate
	
	

}
