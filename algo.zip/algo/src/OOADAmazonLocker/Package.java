package OOADAmazonLocker;

public abstract class Package {
	
	int size;
	 int packaeid;
	 
	 int orderid;
	 
	 

}
