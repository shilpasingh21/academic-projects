package TreeMore;

public class DeleteBST {
	
	Node root;
	
	class Node {
		
		int data;
		
		Node leftChild;
		
		Node rightChild;
		
		Node(int value){
			
			data= value;
			
			leftChild =null;
			
			rightChild = null;
		}
	}
	
	
	public boolean delete(int value) {
		
		Node current = root;
		
		Node parent = null;
		
		while(current !=null && current.data != value) {
			
			Node left = current.leftChild;
			
			Node right = current.rightChild;
			
			parent = current;
			
			if(value > current.data) {
				
				current = current.rightChild;
			}
			
			if(value < current.data) {
				
				current = current.leftChild;
			}
		}
		
		if(current == null) {
			
			return false;
		}
		
		if(current.leftChild == null && current.rightChild ==null) {
			
			if(current.data > parent.data) {
				
				parent.rightChild = null;
			}
			
			else {
				
				parent.leftChild = null;
			}
			
			return true;
		}
		
		else if(current.leftChild != null) {
			
			if(current.data > parent.data) {
				
				parent.rightChild = current.leftChild;
			}
			
			else {
				
				parent.leftChild = current.leftChild;
			}
			
			return true;
		}
		
		else if(current.rightChild != null) {
			
			if(current.data > parent.data) {
				
				parent.rightChild = current.rightChild;
			}
			
			else {
				
				parent.leftChild = current.rightChild;
			}
			
			return true;
		}
		
		else {
			
			Node temp = current.rightChild;
			
			Node parenttemp = null;
			
			while (temp.leftChild !=null) {
				
				parent = temp;
				
				temp = temp.leftChild;
				
			}
			
			int val = temp.data;
			
			temp.data = current.data;
			
			current.data = val;
			
			parent.leftChild = null;
			
			return true;
			
		}
		
	}
	
}
