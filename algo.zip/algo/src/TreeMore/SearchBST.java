package TreeMore;

// Time complexity O(logN)

public class SearchBST {

	Node root;

	class Node {

		int data;
		Node leftChild;
		Node rightChild;

		Node(int value) {

			data = value;

			leftChild = null;

			rightChild = null;

		}

	}

	public boolean search(int key) {

		if (isEmpty()) {

			return false;

		}

		Node current = root;

		while (current != null) {

			Node left = current.leftChild;

			Node right = current.rightChild;

			if (current.data == key) {

				return true;
			}

			if (key > current.data) {

				// look in the right

				if (right == null) {

					return false;
				}

				else {

					current = current.rightChild;
				}
			}

			else {

				// look in the left

				if (left == null) {

					return false;
				}

				left = current.leftChild;

			}

		}
		
		return false;

	}
	
	
	public boolean isEmpty() {
		
		return root == null;
		
	}

}
