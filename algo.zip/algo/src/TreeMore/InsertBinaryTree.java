package TreeMore;

// Insert a node in a bInary search tree. A BST is one where left<root<right

// Time complexity is O(h)

public class InsertBinaryTree {

	Node root;

	class Node {

		private int data;

		private Node leftChild;

		private Node rightChild;

		Node(int value) {

			data = value;

			leftChild = null;

			rightChild = null;

		}

	}

	// Getter setter

	public boolean add(int value) {

		if (isEmpty()) {

			root = new Node(value);

			return true;

		}

		Node current = root;

		while (current != null) {

			Node left = current.leftChild;

			Node right = current.rightChild;

			if (value > current.data) {

				if (right == null) {

					Node inserted = new Node(value);

					current.rightChild = inserted;
					
					return true;
				}

				else {

					current = current.rightChild;
				}

			}

			else {

				if (left == null) {

					Node inserted = new Node(value);

					current.leftChild = inserted;

					return true;
				}

				else {

					current = current.leftChild;
				}
			}

		}
		
		return false;

	}
	
	
	public boolean isEmpty() {
		
		if(root == null) {
			
			return true;
		}
		
		else {
			
			return false;
		}
	}

}
