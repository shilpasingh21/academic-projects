package TreeMore;

import java.util.ArrayList;

import TreeMore.InsertBinaryTree.Node;

/* Return the kth maximum value from the given tree.
 * bst = {
    6 -> 4,9
    4 -> 2,5
    9 -> 8,12
    12 -> 10,14
}
where parent -> leftChild,rightChild

k = 3
 */

public class KthMaxValue {
	
	static Node root;

	static class Node {

		private int data;

		private Node leftChild;

		private Node rightChild;

		Node(int value) {

			data = value;

			leftChild = null;

			rightChild = null;

		}

	}

	// Getter setter

	public boolean add(int value) {

		if (isEmpty()) {

			root = new Node(value);

			return true;

		}

		Node current = root;

		while (current != null) {

			Node left = current.leftChild;

			Node right = current.rightChild;

			if (value > current.data) {

				if (right == null) {

					Node inserted = new Node(value);

					current.rightChild = inserted;
					
					return true;
				}

				else {

					current = current.rightChild;
				}

			}

			else {

				if (left == null) {

					Node inserted = new Node(value);

					current.leftChild = inserted;

					return true;
				}

				else {

					current = current.leftChild;
				}
			}

		}
		
		return false;

	}
	
	
	public boolean isEmpty() {
		
		if(root == null) {
			
			return true;
		}
		
		else {
			
			return false;
		}
	}
	

	public static ArrayList<Integer> preTraverse() {

		ArrayList<Integer> output = new ArrayList<Integer>();
		
		preTraverseInternal(root, output);
		
		return output;
		
	}
	
	
	
	private static void preTraverseInternal(Node root, ArrayList<Integer> output) {

		if (root == null) {

			return;

		}

		output.add(root.data);

		preTraverseInternal(root.leftChild, output);

		preTraverseInternal(root.rightChild, output);

	}
	
	
	private String getAncestors(Node input) {
		
		if (root == null) {
			
			return "";
		}
		
		StringBuilder builder =new StringBuilder();
		
		Node current = root;
		
		while(current!=null && current.data != input.data) {
			
			builder.append(current.data);
			
			if(input.data < current.data) {
				
				current = current.leftChild;
			}
			
			else {
				
				current = current.rightChild;
			}
			
		}
		
		return builder.toString();
	}
	
	
	
	public int findHeight(Node root) {
		
		if(root==null) {
			
			return -1;
		}
		
		return Math.max(findHeight(root.leftChild), findHeight(root.rightChild)) + 1; 
		
	}
	
	
	public String findNodesAtK( Node root, int k, StringBuilder builder) {
		
		if(root == null) {
			
			return null;
		}
		
		if(k==0) {
			
			builder.append(root.data);
		}
		
		
		findNodesAtK( root.leftChild, k-1, builder);
		
		findNodesAtK( root.rightChild, k-1, builder);
		
		return builder.toString();
		
		
   }
		
		
}
	
	


	
		
		
		
		
		
		
		
		
		
		
		
		
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	


