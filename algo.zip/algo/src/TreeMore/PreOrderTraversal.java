package TreeMore;

public class PreOrderTraversal {

	class Node {

		int data;

		Node leftChild;

		Node rightChild;
	}

	public static void preTraverse(Node root) {

		if (root == null) {

			return;

		}

		System.out.println(root.data);

		preTraverse(root.leftChild);

		preTraverse(root.rightChild);

	}

}
