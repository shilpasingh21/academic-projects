package TreeMore;

import java.util.ArrayList;

import TreeMore.InsertBinaryTree.Node;

public class TestfFunction {
	
		
		public static void main(String[] args) {
			
			int[] input = new int[] {6, 4, 9, 2, 5, 8, 12, 10, 14};
				
				
			KthMaxValue tree = new KthMaxValue();
			
			for(int i=0; i<input.length; i++) {
			
				tree.add(input[i]);
				
			}
			
			// Tree Traversal
			
			
			ArrayList<Integer> output = new ArrayList<Integer>();
			
			output = tree.preTraverse();
			
			for(Integer val: output) {
				
				System.out.println(val);
			}
			
	}
		
		
}
