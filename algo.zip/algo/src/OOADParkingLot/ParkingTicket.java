package OOADParkingLot;

public class ParkingTicket {
	
	private int ticketNo;
	
	private timestamp startTime;
	
	private timestamp endTime;
	
	private double amount;
	
	private String paymentStatus;
	
	private Payment payment;
	
	private int vehicleNo;
	
}
