package OOADParkingLot;

public class Exit {
	
	private int exitid;
	
	public boolean validtaeticket() {
		
		
	}
	
	
	public boolena makepayment() {
		
	}
	
	

}
