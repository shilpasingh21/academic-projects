package OOADParkingLot;

public class Entrance {
	
	private int EntranceId;
	
	public ParkingTicket getTicket() {
		
		
	}
	
	

}
