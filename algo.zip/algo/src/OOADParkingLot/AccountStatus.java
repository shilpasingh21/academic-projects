package OOADParkingLot;

	public enum AccountStatus { 
	
	"ACTIVE",
	"INACTIVE",
	"EXPIRED",
	"BLOCKED"

	}
