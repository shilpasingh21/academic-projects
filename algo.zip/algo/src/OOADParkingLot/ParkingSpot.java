package OOADParkingLot;

// Child classes are Handicapped, bike, Compact, large


public abstract class ParkingSpot {
	
	private int id;
	
	
	private boolean isFree;
	
	
	private Vehicle vehicle;
	
	
	
	public boolean checkisFree() {
		
	}
	
	
	public abstract boolean assignVehicle(Vehicle vehicle) {
		
		
	}
	
	
	public boolean removeVehicle( ) {
		
		
	}
	
}

// Child classes


public class Handicapped extends ParkingSpot {
	
	public boolean assignVehicle(Vehicle vehicle) {
		
		
	}
	
	
}

public class Compact extends ParkingSpot {
	
	public boolean assignVehicle(Vehicle vehicle) {
		
		
	}
	
	
}

public class Large extends ParkingSpot {
	
	public boolean assignVehicle(Vehicle vehicle) {
		
		
	}
	
	
}

public class Bike extends ParkingSpot {
	
	public boolean assignVehicle(Vehicle vehicle) {
		
		
	}
	
	
}





