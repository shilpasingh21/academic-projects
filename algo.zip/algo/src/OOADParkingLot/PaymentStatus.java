package OOADParkingLot;

// Enumeration

enum PaymentStatus {
	
	COMPLETED,
	PENDING,
	CANCELLED
}
