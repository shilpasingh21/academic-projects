package OOADParkingLot;

public abstract class Vehicle {
	
	private int licenceNo;
	
	public abstract void assignTicket(ParkingTicket parkingticket) {
		
		
	}

}

// Child classes


public class Car extends Vehicle {
	
	public void assignTicket(ParkingTicket parkingticket)  {
		
	}
}


public class Bike extends vehicle {
	
	public void assignTicket(ParkingTicket parkingticket)  {
		
	}
	
	
}
