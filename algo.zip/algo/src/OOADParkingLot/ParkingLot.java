package OOADParkingLot;

public class ParkingLot {
	
	privare String address;
	
	private List<Entrace>;
	
	private List<Exit>;
	
	
	private Parking rate;
	
	
	public addEntrance();
	
	public addExit();
	
	public getParkingticket();
	
	public isfull();
	
	
}
