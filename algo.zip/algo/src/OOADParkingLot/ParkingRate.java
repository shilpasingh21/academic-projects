package OOADParkingLot;

public class ParkingRate {
	
	private int hours;
	
	privtate double rate;
	
	public calculateRate() {
		
		
	}

}
