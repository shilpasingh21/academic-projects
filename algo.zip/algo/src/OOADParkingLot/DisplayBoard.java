package OOADParkingLot;

public class DisplayBoard {
	
	private int id;
	
	private Map<String,ArrayList<ParkingSpots>> spots;
	
	public getParkingSpots() {
		
		
	}
	
	public getFreeParkingSpots() {
		
		
	}
	
	public boolean isFree{
		
		
	}
	
}
