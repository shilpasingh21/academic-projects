package OOADParkingLot;

public abstract class Account {
	
	private String username;
	
	private string password;
	
	private Person person;
	
	private Accountstatus status;
	
}


// child classes

public class Admin extends Account {
	
	public getTicket();
	
	public validateTicket();
	
	public addEnstrance();
	
	public removeEnstrance();
	
	public addExit();
	
	public removeExit();
	
	public addparkinglot() {}
	
	public removeparkinglot() {}
	
}


public class ParkingAgent extends Account {
	
	public getTicket();
	
	public validateTicket();
	
}



