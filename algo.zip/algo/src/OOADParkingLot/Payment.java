package OOADParkingLot;

public abstract class Payment {
	
	private double amount;
	
	private PaymentStatus status;
	
	public abstarct boolena initiatetransaction() {
		
	}
	
}



public class Cash extends Payment {
	
	public  boolena initiatetransaction() {
		
	}
	
	
}


public class Credit extends Payment {
	
	public  boolena initiatetransaction() {
		
	}
	
	
}

