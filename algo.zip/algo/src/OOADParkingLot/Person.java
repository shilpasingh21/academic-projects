package OOADParkingLot;

public abstract class Person {
	
	private String name;
	
	private string address;
	
	

}
