
import java.util.*;

// "duel", "dule", "speed", "spede", "deul", "cars"

public class GroupTitles {

    static Map<String, List<String>> wordmap = new HashMap<String, List<String>>();

    public static void main(String[] args) {

        String[] input_words = {"duel", "dule", "speed", "spede", "deul", "cars"};
        String input = "duel";
        storeWords(input_words);
        System.out.println("print word map");
        System.out.println(wordmap.toString());
        List<String> output = getMatchingWords("dule");

        for (String word: output) {
            System.out.println(word);
        }

    }

    private static List<String> getMatchingWords(String input) {
        String sorted = sort(input);
        return wordmap.get(sorted);
    }

    private static void storeWords(String[] input_words) {

        for (String word : input_words) {
            String sorted = sort(word);
            if (wordmap.containsKey(sorted)) {
                List<String> strings = wordmap.get(sorted);
                strings.add(word);
                wordmap.put(sorted, strings);
            } else {
                List<String> words = new ArrayList<String>();
                words.add(word);
                wordmap.put(sorted, words);
            }
        }
    }

    private static String sort(String word) {
        char[] chars = word.toCharArray();
        Arrays.sort(chars);
        String output = String.valueOf(chars);
        System.out.println("word: " + word);
        System.out.println("sorted: " + output);
        return output;
    }

}

























