package OOADVendingMachine;

/* It will have a product. Prodict id, price, product category.
 * There will be a rack. racknumber, isempty()
 * 
 * State: Inserted, uniserted, idspensed.
 * 
 * Invetory: list of procuyts, assigproduct to arack,remoce product froma rack.
 * 
 * Vendingmachine:  Stae, amount, no of racks,
 * list of racks, list of emptyrtacks,
 * 
 * 
 * 
