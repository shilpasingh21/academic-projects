package dsapplicationGoogleCalender;

import java.util.*;

public class TwoSubarrysWithTargetSum {
	
	public static void main(String[] args) {
		
		int[] hoursPerday = {1, 2, 2, 3, 2, 6, 7, 2, 1, 4, 8 };
		
		int K= 5;
		
	}
	
	public static int twoSetsOfDays(int[] hoursPerDay, int k) {
		
		HashMap < Integer, Integer > hmap = new HashMap < >();
		
		int sum =0;
		
		int lsize = Integer.MAX_VALUE; 
		
		int result = Integer.MAX_VALUE;
		
		hmap.put(0, -1);
		
		for (int i = 0; i < hoursPerDay.length; i++) {
			
			sum = sum + hoursPerDay[i];
			
			hmap.put(i, sum);
		}
		
		sum =0;
		
		for(int i= 0;i<hoursPerDay.length; i++) {
			
			sum = sum + hoursPerDay[i];
			
			if (hmap.get(sum - k) != null) {
                // stores minimum length of sub-array ending with index<= i with sum k. This ensures non- overlapping property.
                lsize = Math.min(lsize, i - hmap.get(sum - k)); 
            }
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	

}
