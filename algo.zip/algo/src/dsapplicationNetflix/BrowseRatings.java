package dsapplicationNetflix;

import java.util.*;

/* In this feature, the user will be able to randomly browse through movie titles and read their summaries and reviews. 
 * We want to enable a Back button so the user can return to the previous title in the viewing history. 
 * We also want the user to immediately get the title with the highest viewer rating from their viewing history. 
 * We want to implement both of these operations in constant time to provide a good user experience.*/

public class BrowseRatings {

	static Stack<Integer> titles = new Stack<Integer>();

	static Stack<Integer> maxratings = new Stack<Integer>();

	public static void main(String[] args) {
		
		int[][] input = new int[][] {
			
			{1,100},
			{2,50},
			{3,300},
			{4,400},
			{5,500},
			{6,600},
			{7,700},
			{8,800},
			{9,900},
			{10,1000}
		};
		
		insert(new int[] {1,100});
		
		insert(new int[] {2,50});
		
		insert(new int[] {3,300});
		
		System.out.println(getMaxRating());
		
		System.out.println(getBackbutton());
		
		
		
	}

	public static void insert(int[] title) {

		titles.push(title[0]);

		int max = 0;
		
		if(maxratings.isEmpty()) {
			
			maxratings.push(title[1]);
			
		}

		max = maxratings.peek();

		if (title[1] > max) {

			maxratings.push(title[1]);
		}

		else {
			
			maxratings.push(max);
		}

	}

	public static Integer getBackbutton() {

		maxratings.pop();

		return titles.pop();
	}

	public static Integer getMaxRating() {

		return maxratings.peek();
	}

}
