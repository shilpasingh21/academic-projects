package dsapplicationNetflix;

import java.util.*;

/* we need to figure out a way to individually group all the character combinations of each title. 
 * Suppose the content library contains the following titles: "duel", "dule", "speed", "spede", "deul", "cars". 
 * How would you efficiently implement a functionality 
 * so that if a user misspells speed as spede, they are shown the correct title?
 */

/* Input: ["duel", "dule", "speed", "spede", "deul", "cars".]
 * 
 * Output : [["duel", "dule",deul],["speed", "spede"],[cars]]
 */

public class GroupSimilarTitles {

	public static void main(String[] args) {

		Map<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

		String[] inputs = new String[] { "duel", "dule", "speed", "spede", "deul", "cars" };

		for (int i = 0; i < inputs.length; i++) {

			String temp = inputs[i];

			char[] input = inputs[i].toCharArray();

			Arrays.sort(input);
			
			String key = String.valueOf(input);

			if (map.containsKey(key)) {

				map.get(key).add(temp);

			}

			else {

				ArrayList<String> templist = new ArrayList<String>();

				templist.add(temp);

				map.put(key, templist);
			}

		}

		String inputkey = "speed";

		ArrayList<String> output = getsimilarTitles(inputkey, map);

		for (String temp : output) {

			System.out.println(temp);
		}

	}

	public static ArrayList<String> getsimilarTitles(String input, Map<String, ArrayList<String>> map) {

		char[] temp = input.toCharArray();

		Arrays.sort(temp);
		
		String key = String.valueOf(temp);

		if (map.containsKey(key)) {

			return map.get(key);
		}

		return null;

	}

}
