package dsapplicationNetflix;

import java.util.*;

/* Popt the most frequently used */

// Time Complexity for push : O(1), pop: O(1)

public class ContinuewatchingBarStack {
	
	int maxFrequency;
	
	Map<String, Integer> map;
	
	Map<Integer, LinkedList<String>> group;
	
	ContinuewatchingBarStack(){
		
		maxFrequency = 0;
		
		map = new HashMap<String, Integer>();
		
		group = new HashMap<Integer, LinkedList<String>>();
		
	}
	
	public void push(String movieName) {
		
		int frequency = map.getOrDefault(movieName, 0) +1;
		
		map.put(movieName, frequency);
		
		LinkedList<String> list = group.get(frequency);
		
		list.addFirst(movieName);
		
	}
	
	public String pop() {
		
		LinkedList<String> list = group.get(maxFrequency);
		
		String lastElement = list.getFirst();
		
		if(list.isEmpty()) {
			
			group.remove(maxFrequency);
		}
		
		maxFrequency = maxFrequency -1;
		
		map.remove(lastElement);
		
		return lastElement;
		
	}
	
}
	

