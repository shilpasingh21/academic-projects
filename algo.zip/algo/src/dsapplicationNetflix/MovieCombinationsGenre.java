package dsapplicationNetflix;

import java.util.*;

public class MovieCombinationsGenre {

	static String[] categories = new String[] { "Family", "Action", "Fantasy", "Comedy", "Horror" };

	static Map<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
	
	static List<String> combinations = new ArrayList<String>();

	public static void main(String[] args) {

		ArrayList<String> list1 = new ArrayList<String>();

		list1.add("Frozen");

		list1.add("Kung fu Panda");

		list1.add("Ice Age");

		ArrayList<String> list2 = new ArrayList<String>();

		list2.add("Iron Man");

		list2.add("Wonder Woman");

		list2.add("Avengers");

		ArrayList<String> list3 = new ArrayList<String>();

		list3.add("Jumanji");

		list3.add("Lion King");

		list3.add("Tarzan");

		ArrayList<String> list4 = new ArrayList<String>();

		list4.add("coco");

		list4.add("vivo");

		list4.add("pets");

		ArrayList<String> list5 = new ArrayList<String>();

		list5.add("Oculus");

		list5.add("sinister");

		list5.add("Insiduous");

		map.put("Family", list1);

		map.put("Action", list2);

		map.put("Fantasy", list3);

		map.put("Comedy", list4);

		map.put("Horror", list5);
		
		String[] categories1 = new String[] {"Family","Action"};
		
		combinations = getCombinations(categories1);
		
		String joined = String.join(",", combinations);
		
		System.out.println(joined);
		
		

		}
	
	
	public static List<String> getCombinations(String[] categories) {
		
		if(categories.length == 0) {
			
			return combinations;
		}
		
		ArrayList<String> path = new ArrayList<String>();
		
		backtrack(categories, 0, path);
		
		return combinations;
		
	}

	public static void backtrack(String[] categories, int currentIndex, ArrayList<String> path) {

		if (path.size() == categories.length) {

			combinations.add(String.join("", path));

			return;

		}

		ArrayList<String> list = map.get(categories[currentIndex]);

		for (int i=0; i < list.size(); i++) {

			path.add(list.get(i) + ";");

			backtrack(categories, currentIndex + 1, path);
			
			if(path.size() >0) {
				
				path.remove(path.size()-1);
			}
		}

	}

}
