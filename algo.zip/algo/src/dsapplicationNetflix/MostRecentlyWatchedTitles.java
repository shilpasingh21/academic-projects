package dsapplicationNetflix;

import java.util.*;

public class MostRecentlyWatchedTitles {

	class Node {

		String data;

		Node previous;

		Node next;

		Node(String data) {

			this.data = data;
		}
	}

		public static void main(String[] args) {

			String[] titles = new String[] { "ttitle1", "title2", "title3", "title4" };

			List<String> list = new LinkedList<String>();

			Map<String, Integer> map = new HashMap<String, Integer>();

		}

		// The below will remove the object from the doubly linked list. this will be
		// O(n) operation.

		public String insertdata(String title, LinkedList<String> list, Map<String, Integer> map) {

			if (map.containsKey(title)) {

				list.remove(title);

				list.addFirst(title);
			}

			else {

				list.addFirst(title);

				map.put(title, 1);
			}

			return list.getFirst();
		}

		// The below will remove the object in constant time

		public String insertdata(String title) {

			Map<String, Node> map = new HashMap<String, Node>();

			LinkedList<Node> list = new LinkedList<Node>();

			if (map.containsKey(title)) {

				Node old = map.get(title);

				Node previous = old.previous;

				Node next = old.next;

				previous.next = next;

				Node newNode = new Node(title);

				map.put(title, newNode);

				list.addLast(newNode);
			}

			else {

				Node newNode = new Node(title);

				map.put(title, newNode);

				list.addLast(newNode);

			}

			return list.getLast().data;
		}

	}

