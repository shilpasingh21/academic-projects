package dsapplicationNetflix;

import java.util.*;



public class FindMedianAge {
	
	public static void main(String[] args) {
	
		int[] input = new int[] {25,30,35,40,45, 46, 2, 3, 4, 5};
		
		int median =0;
	
		PriorityQueue<Integer> minqueue = new PriorityQueue<Integer>();
	
		PriorityQueue<Integer> maxqueue = new PriorityQueue<Integer>(Collections.reverseOrder());
	
		
		for(int i=0; i<input.length; i++) {
			
			minqueue.add(input[i]);
			
			if(minqueue.size() - maxqueue.size() >1) {
				
				int min = minqueue.poll();
				
				maxqueue.add(min);
			}
		}
		
		System.out.println(getMedian(minqueue, maxqueue, input.length));
		
		
		
	}
	
	
	public static int getMedian(PriorityQueue<Integer> minqueue, PriorityQueue<Integer> maxqueue, int inputlength) {
		
		
		int median = 0;
		
		if(inputlength%2 ==0) {
			
			median = minqueue.poll() + maxqueue.poll()/2;
		}
		
		else {
			
			median = minqueue.poll();
		}
		
		return median;
	}
	
	
	
	
			
			
	
	
	
	
	

}
