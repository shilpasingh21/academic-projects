package dsapplicationNetflix;

public class PopularityAnalytics {
	
	public static void main(String[] args) {
		
		int[] input = new int[] {50,40,30,20,10};
		
		System.out.println(ismonotonic(input));
	}
	
	
	public static boolean ismonotonic(int[] input) {
		
		if(isIncreasing(input)) {
			
			return true;
		}
		
		if(isDecreasing(input)) {
			
			return true;
		}
		
		return false;
		
	}
	
	public static boolean isIncreasing(int[] input) {
		
		for(int i=0;i<input.length-1; i++) {
			
			if(input[i+1] < input[i]) {
				
				return false;
			}
		}
		
		return true;
		
	}
	
	
	public static  boolean isDecreasing(int[] input) {
		
		for(int i=0;i<input.length-1; i++) {
			
			if(input[i+1] > input[i]) {
				
				return false;
				
				
			}
		}
		
		return true;
		
		
	}
	
	
	
	

}
