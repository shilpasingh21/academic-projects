package dsapplicationNetflix;

import java.util.*;



public class MovieCombo{
  // Declaring the combinations variable
  private static List<String> combinations = new ArrayList<String>();

  static String[] list1 = {"Frozen", "Kung fu Panda", "Ice Age"};
  static String[] list2 = {"Iron Man","Wonder Woman","Avengers"};
  static String[] list3 = {"Jumangi", "Lion King", "Tarzan"};
  static String[] list4 = {"Coco", "The Croods", "Vivi","Pets"};
  static String[] list5 = {"Oculus", "Sinister","Insidious","Annebelle"};

  private static HashMap<String, String[]> movies = new HashMap<>();

  public static List<String> letterCombinations(String[] categories) {
    // Return empty array if input is empty
    if (categories.length == 0) {
      return combinations;
    }

    // Mapping the categories to their corresponding movies
    movies.put("Family", list1);
    movies.put("Action", list2);
    movies.put("Fantasy", list3);
    movies.put("Comedy", list4);
    movies.put("Horror", list5);
    
    // Initiate backtracking with an empty path and starting index of 0
    List<String> path = new ArrayList<String>();
    backTrack(0, path, categories);
    return combinations;
  }

  // Use backTrack function to generate all possible combinations
  private static void backTrack(int index, List<String> path, String[] categories) {
    // If the length of path and categories is same, 
    // we have a complete combinations
    if (path.size() == categories.length) {
      combinations.add(String.join("", path));
      return;
    }
    
    // Using the index and categories[index], get the list of movies
    String[] possibleMovies = movies.get(categories[index]);
    // Loop through the movies and generate combinations
    for(int i =0; i<possibleMovies.length; i++) {
      // Add the movie to our current path
      path.add(possibleMovies[i] + ";");
      // Move on to the next category
      backTrack(index + 1, path,categories);
      // Before moving onto the next movie, 
      // backTrack by removing the movie from the path
      if(path.size() > 0)
        // RemoveIndex is used to remove the element from the path
        path.remove(path.size() - 1);
    }
  }

  public static void main(String[] args) {
    //Example 1
    String[] genres = {"Action"};
    combinations = letterCombinations(genres);
    System.out.println("Output 1:");
    String output = "\"" + String.join("\",\"", combinations) + "\"";
    System.out.println(output);

    //Example 2;
    String[] genres2 = {"Family", "Action"};
    combinations = new ArrayList<String>();
    combinations = letterCombinations(genres2);
    System.out.println("Output 2:");
    output = "\"" + String.join("\",\"", combinations) + "\"";
    System.out.println(output);

    //Example 3;
    String[] genres3 = {"Horror", "Comedy"};
    combinations = new ArrayList<String>();
    combinations = letterCombinations(genres3);
    System.out.println("Output 3:");
    output = "\"" + String.join("\",\"", combinations) + "\"";
    System.out.println(output);

    //Example 4;
    String[] genres4 = {"Horror", "Fantasy", "Comedy", "Family"};
    combinations = new ArrayList<String>();
    combinations = letterCombinations(genres4);
    System.out.println("Output 4:");
    output = "\"" + String.join("\",\"", combinations) + "\"";
    System.out.println(output);
  }
}