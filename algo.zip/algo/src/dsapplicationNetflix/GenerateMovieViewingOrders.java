package dsapplicationNetflix;

import java.util.*;


class GeneratemovieViewingOrders{
	
	public static void main(String[] args) {
	    // Example #1
	    String[] input = {"Frozen","Dune","Coco"};
	    List<List<String>> output = generatePermutations(input);
	    System.out.println("Output 1: " + output);

	    // Example #2
	    String[] input2 = {"Frozen","Dune","Coco","Melificient"};
	    output = generatePermutations(input2);
	    System.out.println("Output 2: " + output);

	    // Example #3
	    String[] input3 = {"Dune","Coco"};
	    output = generatePermutations(input3);
	    System.out.println("Output 3: " + output);
	  }
	
	public static List<List<String>> generatePermutations(String[] movies) {
	    List<List<String>> output = new LinkedList<>();
	    int size = movies.length;

	    // convert movies into list since the output is a list of lists
	    ArrayList<String> moviesList = new ArrayList<String>();
	    for (String movie : movies)
	      moviesList.add(movie);

	    backTrack(0, size, moviesList, output);

	    return output;
	 }
  
	public static void backTrack(int first, int size, List<String> moviesList, List<List<String>> output) {
    // If all strings of given array `moviesList` are used and 
    // and Backtracking is performed add the permutations to output array.
    if (first == size) {
      List<String> temp = new ArrayList<String>(moviesList);
      output.add(temp);
    }

    // Perform Backtracking for the size of a given array.
    for (int i = first; i < size; i++) {
      
      // Swap: In the current permutation place i-th integer first.
      Collections.swap(moviesList, first, i);
      
      // Complete permutations using the next integers.
      backTrack(first + 1, size, moviesList, output);
      
      // Swap and Backtrack
      Collections.swap(moviesList, first, i);
    }
  }

  

  
}