package dsapplicationNetflix;

import java.util.*;

public class GenerateMovieorders {

	public static void main(String[] args) {

		String[] input1 = new String[] { "Frozen", "Duna", "Coco" };
		
		List<ArrayList<String>> output1 = generateCombination(input1);
		
		System.out.println("Output 1: " + output1);
		
		String[] input2 = new String[] { "Frozen","Dune","Coco","Melificient" };
		
		List<ArrayList<String>> output2 = generateCombination(input2);
		
		System.out.println("Output 2: " + output2);
		
		
	}

	
	public static List<ArrayList<String>> generateCombination(String[] input) {
		
		int size =  input.length;
		
		ArrayList<String> newInput = new ArrayList<String>();
		
		for(int i=0; i<input.length; i++) {
			
			newInput.add(input[i]);
		}
		
		List<ArrayList<String>> output = new ArrayList<ArrayList<String>>();
		
		backTrack(0, size, output, newInput);
		
		return output;
		
	}

	public static void backTrack(int first, int size, List<ArrayList<String>> output, ArrayList<String> input) {

		if (first == size) {
			
			ArrayList<String> temp = new ArrayList<String>(input);

			output.add(temp);

			return;

		}

		for (int i = first; i < size; i++) {

			Collections.swap(input, first, i);

			backTrack(first + 1, size, output, input);

			Collections.swap(input, first, i);
		}

	}

}
