package dsapplicationNetflix;

import java.util.*;
/* There are 2 approaches:
 * 
 * 1. Use a map to save key, value. Priority queue to save keys.
 * 
 * Insert compexity : Map  O(1) ; priority queue(O logN); 
 * 
 * Deletre complexity: Map(O N); iterat ethrough al the values; find the min and delete it. Deletion from the priority quee is O(N}
 * 
 * Read:  redaing the most frequenl;y used values from priority quque is O(log N)
 * 
 * 
 * 2. Use  a to save keys and counts. Use  atree mpa<count, linkedlist> to save the data.
 * 
 * Insert time: 0(1) + removing old entry for eveet new count increase 0{N]; there will be a delete every time an existing count
 *  is updated
 *  
 *  Deelete from the teee map O(N)
 *  
 *  Reda: O(log N) from the tree map. It will give the list.
 *  
 *  
 * 
 */

public class MostFrequentlyUsed {
	
	public static void main(String[] args) {
		
		Map<String,Integer> map = new HashMap<String,Integer>();
		
		PriorityQueue<String> queue = new PriorityQueue<String>((a,b) -> map.get(b) - map.get(a));
		
		String input[] = new String[] {"title1", "title2", "title3", "title4", "title5", "title6", 
				"title4", "title5", "title5","title6","title6","title6","title6" };
		
		for(int i=0; i<input.length; i++) {
			
			String title = input[i];
			
			map.put(title, map.getOrDefault(title, 0) +1);
		}
		
		queue.addAll(map.keySet());
		
		int N = 4;
		
		ArrayList<String> list = getTopN(N,queue);
		
		for(String temp : list) {
			
			System.out.println(temp);
		}
	}
	
	
	public static ArrayList<String> getTopN(int N, PriorityQueue<String> queue) {
		
		ArrayList<String> output = new ArrayList<String>();
		
		for(int i=1; i<=N ;i++) {
			
			if(!queue.isEmpty()) {
				
				output.add(queue.poll());
				
			}
		}
		
		return output;
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	

}
