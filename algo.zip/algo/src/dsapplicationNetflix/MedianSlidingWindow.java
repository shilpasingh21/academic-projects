package dsapplicationNetflix;

import java.util.*;

public class MedianSlidingWindow {
	
	public static void main(String[] args) {
		
		int[] input = new int[] {1,3,-1,2,-2,-3,5,1,5,3};
		
		List<Float> output = new ArrayList<Float>();
		
		int K =4;
		
		for(int i=0; i<=input.length-K;i++) {
			
			int start = i;
			
			int end = i+K-1;
			
			float median = getMedian(start, end, input, K);
			
			output.add(median);
		}
		
		for(Float term: output) {
			
			System.out.println(term);
		}
		
	}
	
	
	public static float getMedian(int start, int end, int[] input, int K) {
		
		int mid = (start + end)/2;
		
		float median;
		
		if (K%2 ==0) {
			
			median = (input[mid]+ input[mid+1])/2;
			
			return median;
		}
		
		else {
			
			return(input[mid]);
		}
			
	}
}
