package dsapplicationNetflix;

import java.util.*;

/* we need to build a criterion so the top movies from multiple countries will combine into a single list of top-rated movies. 
 * In order to scale, the content search is performed in a distributed fashion. Search results for each country 
 * are produced in separate lists. Each member of a given list is ranked by popularity, 
 * with 1 being most popular and popularity decreasing as the rank number increases.
 * We’ll be given n arrays that are all sorted in ascending order of popularity rank. We have to combine these 
 * lists into a single list that will be sorted by rank in ascending order, 
 * meaning from best to worst.
 */

/* Input : [11,23,32,38], [1,44],[23,57,99]
 * 
 * Output : 
 */

/* Approach : O(NlogN) -> N = m+n  add all elements to the list and sort.
 * 
 * O(NK) if we take 3 pointers and start comparing and adding.-- N is the total number, k is the number of lists.
 * 
 * O(N log k) where k is the number of lists with the help of Priority queue.
 * 
 */

public class FetchTopMovies {
	
	public static void main(String[] args) {
	
		int[][] input = new int[][] {
			
			{11,23,32,38},
			{1,44},
			{23,57,99}
		
		};
		
		List<LinkedList<Integer>> inputlist = new ArrayList<LinkedList<Integer>>();
		for(int i=0; i<input.length; i++) {
			LinkedList<Integer> temp = new LinkedList<Integer>();
			for(int j=0; j<input[0].length; j++) {
				temp.add(input[i][j]);
			}
			inputlist.add(temp);
		}
		
		
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for(int i=0; i<input.length; i++) {
			map.put(input[i][0],i);
		}
		
		PriorityQueue<Integer> queue = new PriorityQueue<Integer>();
		queue.addAll(map.keySet());
		ArrayList<Integer> output = new ArrayList<Integer>();
		while(!queue.isEmpty()) {
			Integer min = queue.poll();
			output.add(min);
			Integer listno = map.get(min);
			inputlist.get(listno).removeFirst();
			map.put(min, listno);
		}
	}
}
