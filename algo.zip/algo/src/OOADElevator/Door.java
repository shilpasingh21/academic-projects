package OOADElevator;

public class Door {
	
	sttaus;
	
	boolean isopen();
	
		
		

}
