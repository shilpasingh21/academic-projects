package OOADElevator;

public abstract class Button {
	
	private string status;
	
	public abstarct boolean ispressed();
	
}


public HallButton extends Button {
	
	direction;
	
	public ispressed(0)
	
	
}



public ElevatorButton extensdButton {
	
	florrnumber;
	
	public is pressed();
	
	
}
