package OOADElevator;

public class Display {
	
	public Halldisplay showHallDisplay();
	
	public Elevatordisplay showelevatorDisplay();
	
	

}
