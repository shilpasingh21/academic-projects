package OOADElevator;

public class Building {
	
	List<elevatorcors>;
	
	List<floors>
	

}
