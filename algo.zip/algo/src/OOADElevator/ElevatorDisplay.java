package OOADElevator;

public class ElevatorDisplayPanel {
	
	int capacity;
	
	int floornumber;
	
	Direction direction;
	
}
