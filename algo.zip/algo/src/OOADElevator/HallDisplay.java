package OOADElevator;

public class HallDisplay {
	
	int floorNumber;
	
	Direction direction;

}
