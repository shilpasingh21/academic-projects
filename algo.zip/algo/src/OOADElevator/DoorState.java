package OOADElevator;

public enum DoorState {
	
	open,
	closed

}
