package OOADElevator;

public class HallPanel {
	
	 HallButton UpButton
	
	 HallButton DownButton;
	
}
