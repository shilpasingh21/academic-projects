
// The elevator will have a floor button. The floor button will have the direction up and down.

// The floor will also have a display. The display will show which floor the elevator car is and in which direction it is going.

// The elevator car will have the elevator button. The button will have the floor number.

// The elevator car will also have the elevator panel. The panel will have the list of buttons with the floor number 
//and the direction of going up/down.


//The elevator car will have a display which will show the current floor and the direction of moving.


//The elevtaor car will have door.abstract

// The building will have floors and each floor will have multipl floor panesl and buttons


// The building will have s ingle elevator system.








