package OOADElevator;

public enum Direction {
	
	up, 
	down

}
