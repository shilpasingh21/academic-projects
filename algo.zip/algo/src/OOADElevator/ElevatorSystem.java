package OOADElevator;

public class ElevatorSystem {
	
	Building;
	
	public voiud moitoring();;
	
	public voiud dispather();;
	
	
	
	
	
	

}
