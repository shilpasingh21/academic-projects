package OOADElevator;

public enum  ElevatorState {
	
	Stop,
	
	moving

}
