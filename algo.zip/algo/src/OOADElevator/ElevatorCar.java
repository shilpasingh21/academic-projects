package OOADElevator;

public class ElevatorCar {
	
	id;
	
	ElevatorPanel
	
	elevtaitdisplay
	
	Door door;
	
	state;
	
	
	
	move()
	
	stop()
	
	opendoor()
	
	
	closedoor(0)
	
	
	
	
	
	
	
	

}
