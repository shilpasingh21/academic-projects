package OOADElevator;

public class ElevatorPanel {
	
	List<ElevatorButton> floorbuttons;
	
	Doorbutton open;
	
	Doorbutton close;
	
	
}
