package OOADElevator;

public class Floor {
	
	List<floorPanel)> panels;
	
	int floorNumber;
	
	public boolena isbottonmost() {}
	
	public boolena istopmost() {}
	
}
