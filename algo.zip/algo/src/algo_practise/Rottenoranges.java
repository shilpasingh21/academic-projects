package algo_practise;

import java.util.*;

public class Rottenoranges {
	
	
	static class Point {
		
		int x;
		int y;
		int level;
	
	  Point(int x, int y, int level){
		  
		  this.x = x;
		  
		  this.y = y;
		  
		  this.level = level;
	  }
	
	}
	
	
	
	
	public static void main(String[] args) {
		
		int[][] input = new int[][] {
			
			{2,1,1},
			{0,1,1},
			{1,0,1}
		};
		
		int rows = input.length;
		
		int cols = input[0].length;
		
		boolean[][] visited = new boolean[rows][cols] ;
		
		for(int i=0; i<rows; i++) {
			
			for(int j=0; j<cols; j++) {
				visited[i][j] = false;
				
			}
		}
		
		PriorityQueue<Integer> queue = new PriorityQueue<Integer>(Collections.reverseOrder());
		
		for(int i=0; i<rows; i++) {
			
			for(int j=0; j<cols; j++) {
				
				if(input[i][j] ==2 && visited[i][j] == false) {
				
					queue.add(getLevel(input, i, j, rows,cols, visited));
				}
				
			}
				
	   }
		
		for(int i=0; i<rows; i++) {
			
			for(int j=0; j<cols; j++) {
				
				if(input[i][j] ==1) {
					
					System.out.println(-1);
					
				}
				
			}
			
		}
		
		
		System.out.println(queue.poll());
		
		
		
		
		
	}
	
	
	public static int getLevel(int[][] input, int x, int y, int rows, int cols, boolean[][] visited) {
		
		Queue<Point> queue = new LinkedList<Point>();
		
		int[] x_dir = new int[]{-1, 0, 1, 0};
		
		int[] y_dir = new int[]{0, -1, 0, 1};
		
		Point point = new Point(x,y,0);
		
		queue.add(point);
		
		int level =0;
		
		while (!queue.isEmpty()) {
			
			Point current = queue.poll();
			
			visited[current.x][current.y] = true;
			
			level = current.level;
			
			for(int i=0; i<x_dir.length; i++) {
				
				int new_x = current.x + x_dir[i];
				
				int new_y = current.y+ y_dir[i];
				
				if(new_x >=0 && new_y >=0 && new_x < rows && new_y <cols && input[new_x][new_y] ==1) {
				
					Point point1 = new Point(new_x,new_y, current.level +1);
					
					queue.add(point1);
					
					input[new_x][new_y] = 2;
					
				}
				
			}
			
		}
		
		
		return level;
		
		
	}

}
