package algo_practise;

import java.util.*;

/* Given an array of meeting time intervals intervals 
 * where intervals[i] = [starti, endi], return the minimum number of conference rooms required.
 * Input: intervals = [[0,30],[5,10],[15,20]]
 */

public class MeetingRooms {
	
	public static void main(String[] args) {
		
		
		int[][] input = new int[][] {
			{7,10},
			{2,4},
			
		};
		
		int size = getcount(input) ;
		
		System.out.println(size);
		
	}
	
	
	public static int getcount(int[][] input) {
		
		
		Map<String,Integer> map =new HashMap<String,Integer>();
		
		
		for(int i=0;i<input.length; i++) {
			
			Integer input_start = Integer.valueOf(input[i][0]);
			
			Integer input_end = Integer.valueOf(input[i][1]);
			
			if(map.isEmpty()) {
				
				String key = input_start + "," + input_end;
				
				map.put(key, 1);
			}
			
			for(Map.Entry<String,Integer> entry: map.entrySet()) {
				
				String interval = entry.getKey();
				
				Integer start = Integer.valueOf(interval.split(",")[0]);
				
				Integer end = Integer.valueOf(interval.split(",")[1]);
				
				if(input_start < start) {
					
					if(input_end < start) {
						break;
					}
					
					else {
						
						String newkey = input_start + "," + input_end;
						map.put(newkey, 1);
					}
				}
				
				else if(start < input_start) {
					
					if(end < input_start) {
						
						break;
					}
					
					else {
						
						String newkey = input_start + "," + input_end;
						map.put(newkey, 1);
					
					}
					
					
				}
				
			}
			
		}
		
		return map.size();
		
		
	}

}
