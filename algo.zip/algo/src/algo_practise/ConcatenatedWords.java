package algo_practise;

import java.util.*;

public class ConcatenatedWords {

	public static void main(String[] args) {

		String[] input = new String[] { "cat", "cats", "catsdogcats", "dog", "dogcatsdog", "hippopotamuses", "rat",
				"ratcatdogcat" };

		Set<String> dict = new HashSet<String>();

		int minlen = 999;

		for (String word : input) {

			dict.add(word);

			minlen = Math.min(word.length(), minlen);
		}

		List<String> output = new ArrayList<String>();

		for (String word : input) {

			if (word.length() > minlen) {

				for (int i = 0; i < word.length(); i++) {

					String sub = word.substring(i);

					boolean isconattenated = checkcontatenated(sub, dict);

					if (isconattenated) {

						output.add(word);
					}
				}
			}
		}

		for (String word : output) {

			System.out.println(word + " in output");
		}

	}

	public static boolean checkcontatenated(String input, Set<String> dict) {

		for (int i = 1; i < input.length(); i++) {

			String left = input.substring(0, i);

			String right = input.substring(i);

			if (dict.contains(left) && dict.contains(right)) {

				return true;
			}
		}

		return false;
	}

}
