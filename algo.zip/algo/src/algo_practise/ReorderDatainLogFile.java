package algo_practise;

import java.util.*;

/* given an array of logs */

/* Input: logs = ["dig1 8 1 5 1","let1 art can","dig2 3 6","let2 own kit dig","let3 art zero"] */

public class ReorderDatainLogFile {
	
	
	public static String[] sortlogs() {
	
	
		String[] logs = new String[] {"dig1 8 1 5 1","let1 art can","dig2 3 6","let2 own kit dig","let3 art zero"};
	
		Arrays.sort(logs, (log1,log2) -> {
		
			String split1 = log1.split(" ",2)[1];
		
			String split2 = log2.split(" ",2)[1];
			
			String first1 = log1.split(" ",2)[0];
			
			String first2 = log2.split(" ",2)[0];
		
		
			boolean isDigit1 = Character.isDigit(split1.charAt(0));
		
			boolean isDigit2 = Character.isDigit(split2.charAt(0));
		
		
			if(!isDigit1 && !isDigit2) {
			
				int cmp = split1.compareTo(split2);
			
				if(cmp == 0) {
				
					cmp = first1.compareTo(first2);
				}
			
				return cmp;
			
			}
		
			return isDigit1 ? (isDigit2 ? 0: 1) : -1;
	
		});
		
		return logs;
	}


	public static void main(String[] args) {
		
		String[] answ = sortlogs();	
		
		for(String str: answ) {
			
			System.out.println(str);
		}
		
	}

}
		
		
	
	
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		   
	   
	
	
	
	
	
	
	
	
	
	
	
	


