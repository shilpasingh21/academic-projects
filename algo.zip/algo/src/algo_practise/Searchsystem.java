package algo_practise;

import java.util.*;

public class Searchsystem {
	
	public static void main(String[] args) {
		
		String[] products = new String[] {"mobile","mouse","moneypot","monitor","mousepad"};
		
		String searchWord = "mouse";
		
		Map<String,ArrayList<String>> map = new HashMap<String,ArrayList<String>>();
		
		for(int i=1; i<=searchWord.length(); i++) {
			
			String temp = searchWord.substring(0,i);
			
			ArrayList<String> words = new ArrayList<String>();
			
			for(int j=0; j<products.length; j++) {
				
				if(products[j].startsWith(temp)) {
					
					words.add(products[j]);
					
					if(words.size() == 3) {
					
						break;
					}
				}
			 }
			
			Collections.sort(words);
			
			 map.put(temp, words);
		}
		
		for(Map.Entry<String,ArrayList<String>> entry: map.entrySet()) {
			
			System.out.println("key::" + entry.getKey());
			
			System.out.println("value::" + entry.getValue());
		}
			
			
	}

}
