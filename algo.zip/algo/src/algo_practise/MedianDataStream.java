package algo_practise;

import java.util.*;

public class MedianFinder {
	
	
	private PriorityQueue<Integer> lowerqueue;
	
	private PriorityQueue<Integer> upperqueue;
	
	MedianFinder() {
		
		lowerqueue = new  PriorityQueue<Integer>();
		
		upperqueue = new  PriorityQueue<Integer>(Collections.reverseOrder());
		
	}
	
	public void addNum(int input) {
		
		if(lowerqueue.isEmpty()) {
			
			lowerqueue.add(input);
		}
		
		Integer lower = lowerqueue.poll();
		
		if(input > lower) {
			
			upperqueue.add(input);
		}
		
		else {
			
			lowerqueue.add(input);
		}
		
		if (lowerqueue.size() - upperqueue.size() >1) {
			
		     Integer temp = lowerqueue.poll();
		     
		     upperqueue.add(temp);
		     
		 }
		
		else if(upperqueue.size() - lowerqueue.size() >1) {
			
			Integer temp = upperqueue.poll();
			
			lowerqueue.add(temp);
			
		}
		
	}
	
	public double findMedian() {
		
		double median =0;
		
		if(lowerqueue.size() == upperqueue.size()) {
			
			median = lowerqueue.poll() + upperqueue.poll()/2;
				
		}
		else if(lowerqueue.size()> upperqueue.size()){
			
			median = lowerqueue.poll();
			
			
		}
		
		else{
			
			median = upperqueue.poll();
			
		}
		
		return median;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
