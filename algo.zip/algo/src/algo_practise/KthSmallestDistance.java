package algo_practise;

import java.util.*;

public class KthSmallestDistance {
	
	static class Point{
		
		int x; 
		int y;
	
	Point(int x, int y) {
		
		this.x = x;
		this.y =y;
		
		
		}
	
	}
	
	
	public static void main(String[] args) {
		
		Map<Point,Integer> distmap = new HashMap<Point,Integer>();
		
		int k =4;
		
		PriorityQueue<Point> queue = new PriorityQueue<Point>((a,b) -> distmap.get(b) - distmap.get(a));
		
		int[][] input = new int[][] {
			{ 3, 3 },
			{ 5, -1},
			{ -2, 4},
			{ 5, -4},
			{ 7, 8},
			{ 6, 1}
		};
		
		
		for(int i=0; i<input.length; i++) {
			
			int x = input[i][0];
			
			int y = input[i][1];
			
			Integer dist = Math.abs(x*x - y*y);
			
			System.out.println(x + ",,"  + y + ":" + dist);
			
			Point point = new Point(x,y);
			
			distmap.put(point, dist);
			
			queue.add(point);
			
			if(queue.size() > k) {
				
				queue.remove();
			}
			
			
		}
		
		Point result = queue.peek();
		
		System.out.println(result.x + ","  + result.y);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
			
			
			
			
			
			
			
			
		}
		
		
		
		
		
	
	
	
	
	public float kthdistance() {
		
		List<ArrayList<Integer>> input = new ArrayList<ArrayList<Integer>>();
		
		
		
		input.add(new Arraylist<Integer>() {1,2}) ;
		
		
		
		
		
		
		
		
	}
	
	
	
	

}
