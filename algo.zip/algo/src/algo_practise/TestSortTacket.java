package algo_practise;

import java.util.ArrayList;

public class TestSortTacket {
	
	
	public static void main(String[] args) {
		
		SortTracker  tracker = new SortTracker();
		
		tracker.add("bradford", 1);
		
		tracker.add("branford", 2);
		
		ArrayList<String> score = tracker.get();
		
		for(String temp: score) {
			
			System.out.println(temp);
		}
		
		tracker.add("alps", 3);
		
		ArrayList<String> score1 = tracker.get();
		
		for(String temp: score1) {
			
			System.out.println(temp);
		}
		
		tracker.add("orland", 4);
		
		tracker.add("orlando", 5);
		
		ArrayList<String> score3 = tracker.get();
		
		for(String temp: score3) {
			
			System.out.println(temp);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
