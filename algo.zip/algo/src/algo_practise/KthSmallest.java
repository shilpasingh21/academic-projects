package algo_practise;

import java.util.*;

/* The distance of a pair of integers a and b is defined as the absolute difference between a and b.
 * Given an integer array nums and an integer k, return the kth smallest distance among all the pairs
 * nums[i] and nums[j] where 0 <= i < j < nums.length.
 */

public class KthSmallest {
	
	public static void main(String[] args) {
		
		int[] input = new int[] {1,1,1};
		
		int k =2;
		
		PriorityQueue<Integer> queue = new PriorityQueue<Integer>();
		
		Integer kthdist = getDistance(input, k,queue) ;
		
		System.out.println(kthdist);
		
	}
	
	
	public static Integer getDistance(int[] input, int k,PriorityQueue<Integer> queue)  {
		
		for(int i=0; i<input.length-1; i++) {
			
			for (int j =i+1; j<input.length; j++) {
				
				Integer diff = Math.abs(input[i]- input[j]);
				
				queue.add(diff);
				
			}
		}
		
		Integer temp=0;
		
		for(int i=1; i<=k; i++){
			
			temp = queue.remove();
		}
		
		return temp;
		
		
	}

}
