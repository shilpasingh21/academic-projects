package algo_practise;

import java.util.*;

public class SortTracker {

	private Map<Integer, ArrayList<String>> map;

	private Map<String, Integer> readLog;

	final String key = "RANK";

	SortTracker() {

		this.map = new HashMap<Integer, ArrayList<String>>();

		this.readLog = new HashMap<String, Integer>();

		this.readLog.put(key, 0);
	}

	public void add(String name, int score) {

		if (map.containsKey(score)) {

			ArrayList<String> list = map.get(score);

			list.add(name);

			Collections.sort(list, (locationa, locationb) -> {

				return locationa.length() - locationb.length();
			});

			map.put(score, list);
		}

		else {

			ArrayList<String> list = new ArrayList<String>();

			list.add(name);

			map.put(score, list);
		}
	}

	public ArrayList<String> get() {

		Integer rank = readLog.get(key) + 1;

		readLog.put(key, rank);

		return map.get(rank);
	}
	
	
}
