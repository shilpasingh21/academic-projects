package algo_practise;

import java.util.*;

public class KClosetstoOrigin {
	
	public static void main(String[] args) {
		
		
		int[][] input = new int[][] {
			
			{1,3},
			{-2,2}
		};
		
		int k =1;
		
		String point = getdistance(input, k) ;
		
		System.out.println(point);
		
		
		
	}
	
	
	public static String getdistance(int[][] input, int k) {
		
		Map<String, Integer> map = new HashMap<String,Integer>();
		
		PriorityQueue<String> queue = new PriorityQueue<String>((a,b) -> map.get(a) - map.get(b));
		
		for(int i=0; i<input.length; i++) {
			
			int x = input[i][0];
			
			int y = input[i][1];
			
			Integer dist = Math.abs(x*x - y*y);
			
			String key = x+ "," + y;
			
			map.put(key, dist);
			
			queue.add(key);
			
		}
		
		
		String key = null;
		
		for (int i=1; i<=k; i++) {
			
			key = queue.poll();
		}
		
		return key;
				
		
		
	}

}
