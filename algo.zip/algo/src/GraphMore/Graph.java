package GraphMore;

import java.util.*;

public class Graph {
	
	private int vertices;
	
	private List<LinkedList<Integer>> adjlist = new ArrayList<LinkedList<Integer>>();
	
	Graph(int vertices) {
		
		this.vertices = vertices;
		
		adjlist = new ArrayList<LinkedList<Integer>>();
		
		for(int i=0; i<vertices ;i++) {
			
			LinkedList<Integer> edges = new LinkedList<Integer>();
			
			adjlist.add(i, edges);
		}
	}
	
	public void addEdge(int w, int v) {
		
		this.adjlist.get(w).add(v);
	}
	
	
	public ArrayList<Integer> dfsTravel(int s) {
		
		Stack<Integer> stack = new Stack<Integer>();
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		stack.add(s);
		
		while(!stack.isEmpty()) {
			
			Integer current = stack.pop();
			
			list.add(current);
			
			System.out.println("edge::" + current);
			
			Iterator<Integer> itr = this.adjlist.get(current).iterator();
			
			while(itr.hasNext()) {
				
				Integer edge = itr.next();
				
				stack.add(edge);
			}
		}
		
		return list;
	}
	
	
	public static void main(String[] args) {
		
		Graph graph = new Graph(5);
		
		graph.addEdge(4,2);
		
		graph.addEdge(3,1);
		
		graph.addEdge(2,1);
		
		graph.addEdge(2,0);
		
		graph.addEdge(1,0);
		
		graph.dfsTravel(4);
		
		System.out.println("-----");
		
		graph.dfsTravel(3);
		
		System.out.println("-----");
		
		graph.dfsTravel(2);
		
		System.out.println("-----");
		
		graph.dfsTravel(1);
		
		System.out.println("-----");
		
		graph.dfsTravel(0);
		
		
		
		
}



}
				
				
				
				
			
			
			
			
			
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	
		
		
		
		
		
		
			
			
			
			
			
			
		
		
		
		
		
		
		

	
	
	
	


