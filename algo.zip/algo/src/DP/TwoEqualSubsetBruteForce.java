package DP;

/* Given an array of integers, write a function to find if any two subsets of the input array exist such that the sum of both subsets is equal. 
 * You can assume that the array will only consist of positive integers.
 * int set[] = {1, 2, 3, 4};
 * // (The 2 subsets will be 1,4 & 2,3) */

public class TwoEqualSubsetBruteForce {

	public static void main(String[] args) {

		int[] input = new int[] { 1, 2, 3, 4 };

		int sum = 0;

		boolean result;

		for (int i = 0; i < input.length; i++) {

			sum = sum + input[i];
		}

		int sumhalf = sum / 2;

		if (sum % 2 == 0) {

			result = issubsetforsum(input, sumhalf, 0);
		}

		else {

			result = false;

		}

		System.out.println(result);

	}

	public static boolean issubsetforsum(int[] input, int sum, int currentindex) {

		if (sum == 0) {

			return true;
		}

		if (currentindex >= input.length) {

			return false;
		}

		if (input[currentindex] <= sum) {

			if(issubsetforsum(input, sum - input[currentindex], currentindex + 1)) {
				
				return true;
			}
		}
		
		
			
		return issubsetforsum(input, sum, currentindex + 1);
		

			
		

	}
}


