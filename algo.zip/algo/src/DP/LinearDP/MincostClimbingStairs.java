package DP.LinearDP;

public class MincostClimbingStairs {
	
	public static void main(String[] args) {
		
		int[] input = new int[] {1,100,1,1,1,100,1,1,100,1};
		
		System.out.println(getMinCost(input));
		
	
	}
	
	
	public static int getMinCost(int[] input) {
		
		
		int lastIndex = input.length -1;
		
		int[] cost = new int[input.length];
		
		for(int i=lastIndex; i>=0; i--) {
			
			if (i==lastIndex) {
				
				cost[i] = input[i];
			}
			
			else if(i== lastIndex -1) {
				
				cost[i] = Math.min(input[i], input[i] + input[i+1]);
			}
			
			else {
				
				cost[i] = Math.min(input[i] + cost[i+1], input[i] + cost[i+2]);
			}
			
		}
		
		return Math.min(cost[0], cost[1]);
		
		
	}

}
