package DP.LinearDP;

public class HouseRobber {
	
	
	public static void main(String[] args) {
		
		int[] input = new int[] { 2,7,9,3,1};
		
		System.out.println(getProfit(input));
	}
	
	
	public static int getProfit(int[] input) {
		
		int[] profit = new int[input.length];
		
		profit[0] = 2;
		
		profit[1] = 7;
		
		for(int i=2; i<input.length; i++) {
			
			profit[i] = input[i] + profit[i-2];
			
		}
		
		int lastIndex = profit.length-1;
		
		for(int i=0; i< profit.length ; i++) {
			System.out.println(i + "::" + profit[i]);
			
		}
		
		return Math.max(profit[lastIndex], profit[lastIndex-1]);
		
		
	}

}
