package DP.LinearDP;

import java.util.*;

/* Maximum Profit in Job Scheduling
 * We have n jobs, where every job is scheduled to be done from startTime[i] to endTime[i], obtaining a profit of profit[i].

You're given the startTime, endTime and profit arrays, return the maximum profit you can take such that there are 
no two jobs in the subset with overlapping time range.

If you choose a job that ends at time X you will be able to start another job that starts at time X.
 */


public class JobScheduling {
	
	public static void main(String[] args) {
		
		int[] startTime = new int[] {1,2,3,4,6 };
		
		int[] endTime = new int[] { 3,5,10,6,9 };
		
		int[] profit = new int[] { 20,20,100,70,60 };
		
		int[][] input = new int[5][3];
		
		for(int i=0;i<startTime.length; i++) {
			
			input[i] = new int[] {startTime[i], endTime[i], profit[i]};
			
		}
		
		Arrays.sort(input, (a,b) -> {
			
			return Integer.compare(a[0],b[0]) == 0 ? Integer.compare(a[1],b[1]) : Integer.compare(a[0],b[0]);
		});
		
		
	    int[] maxProfit = new int[startTime.length+1];
	    
	    int lastIndex = startTime.length;
		
		maxProfit[lastIndex] = 0;
		
		maxProfit[lastIndex-1] = 60;
		
		for(int i=lastIndex-2; i>=0; i--) {
			
			int nextIndex = lastIndex;
			
			for(int j =i+1; j<input.length; j++) {
				
				if(input[j][0] >= input[i][1]) {
					
					nextIndex = j;	
					
					break;
				}
			}
			
			
			maxProfit[i] = Math.max(input[i][2] + maxProfit[nextIndex] , maxProfit[i+1]);
			
		}
		
		
		for(int i=0; i<maxProfit.length ; i++) {
			
			System.out.println(maxProfit[i]);
		}
			
	}
		
}
