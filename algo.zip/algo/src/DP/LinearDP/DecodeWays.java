package DP.LinearDP;

public class DecodeWays {
	
	public static void main(String[] args) {
		
		String input = "226";
		//System.out.println(input.substring(0));
		
		System.out.println(getways(input));
		
		
		
		}
	
	
	public static int getways(String input) {
		
		int length = input.length();
		
		int[] dp = new int[length+1];
		
		dp[0] = 1;
		
		dp[1] = input.charAt(1) == 0 ? 0: 1;
		
		for(int i=2; i<input.length(); i++) {
			
			Integer firstdigit = Integer.valueOf(input.substring(i-1,i));
			
			Integer seconddigit = Integer.valueOf(input.substring(i-2,i));
			
			if(firstdigit > 0) {
				
				dp[i] = dp[i] + dp[i-1];
			}
			
			if(seconddigit >= 10 && seconddigit <= 26) {
				
				dp[i] = dp[i] + dp[i-2];
			}
		}
		
		for(int i=0; i<dp.length; i++) {
			
			System.out.println(dp[i]);
		}
		
		return dp[dp.length-1];
			
	}
		
		
}
