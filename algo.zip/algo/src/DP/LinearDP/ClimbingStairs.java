package DP.LinearDP;

public class ClimbingStairs {
	
	
	public static void main(String[] args) {
	
		System.out.println(nways(4));
		
	}
	
	public static int nways(int stepno) {
		
		if(stepno < 0) {
			
			return 0;
		}
		
		if(stepno == 0) {
			
			return 1;
		}
		
		return nways(stepno -1) + nways(stepno-2);
		
	}
	
	

}
