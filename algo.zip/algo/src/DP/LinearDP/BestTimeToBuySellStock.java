package DP.LinearDP;

import java.util.PriorityQueue;

public class BestTimeToBuySellStock {
	
	public static void main(String[] args) {
		
		int[] input = new int[] { 7,6,4,3,1 };
		
		int profict = getMaxProfit(input); 
		
		System.out.println(profict);
		
		
		
		
	}
	
	
	public static int getMaxProfit(int[] input) {
		
		int lastindex = input.length -1;
		
		int MaxProfit =0;
		
		int[] profit = new int[input.length];
		
		for(int i=lastindex; i>=0; i--) {
			
			profit[i] = input[i] - getmin(input, 0, i-1);
			
		}
		
		for(int i=0; i<profit.length; i++) {
			
			MaxProfit = Math.max(MaxProfit, profit[i]);
		}
		
		return MaxProfit;
		
	}
	
	
	public static int getmin(int [] input, int startindex, int lastindex) {
		
		int min = 999;
		
		for(int i= startindex; i<=lastindex;i++) {
			
			min = Math.min(min, input[i]);
		}
		
		return min;
		
    }
	
	
	
	

}
