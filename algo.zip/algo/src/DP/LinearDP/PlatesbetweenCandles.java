package DP.LinearDP;

import java.util.*;

public class PlatesbetweenCandles {
	
	public static void main(String[] args) {
		
		String input = "***|**|*****|**||**|*";
		
		int[][] queries = new int[][] {
			
			{1,17},
			{4,5},
			{14,17},
			{5,11},
			{15,16}
		};
		
		List<Integer> output = new ArrayList<Integer>();
		
		for(int i=0; i<queries.length; i++) {
			
			int start = queries[i][0];
			
			int end = queries[i][1] +1;
			
			char[] isubstring = input.substring(start, end).toCharArray();
			
			int totalcount=0;
			
			for(int j=0; j<isubstring.length; j++) {
				
				if(isubstring[j] == '|') {
					
					int count=0;
					
					for(int k = j+1; k<isubstring.length; k++) {
						
						 if(isubstring[k] == '|') {
							 
							 break;
						 }
						 
						 if(k < isubstring.length-1) {
						 
							 count++;
						 }
					}
					
					totalcount = totalcount + count;
				}
			}
			
			output.add(totalcount);
			
			
	   }
		
		for(int i=0; i<output.size(); i++) {
			
			System.out.println(output.get(i));
		}
				
	}

}
