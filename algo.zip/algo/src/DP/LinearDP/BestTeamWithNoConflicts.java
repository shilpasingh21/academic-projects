package DP.LinearDP;

import java.util.Arrays;

public class BestTeamWithNoConflicts {
	
	
	public static void main(String[] args) {
		
		
		int[] scores = new int[] {1,3,5,10,15};
		
		int[] ages = new int[] { 1,2,3,4,5};
		
		int[][] input = new int[5][2];
		
		// input {[5,1],[1,8],[2,9],[3,10]}
		
		for(int i=0; i<scores.length; i++) {
			
			input[i] = new int[] {scores[i], ages[i]};
		}
		
		Arrays.sort(input, (a,b) -> Integer.compare(a[1], b[1]));
		
		int[] maxscores = new int[scores.length+1];
		
		int lastIndex = scores.length;
		
		maxscores[lastIndex] = 0;
		
		maxscores[lastIndex-1] = 15;
		
		for(int i=lastIndex-2; i>=0; i--) {
			
			int nextIncludeIndex = lastIndex;
			
			for(int j= i+1; j<input.length; j++) {
			
				if(input[j][1]>= input[i][1] && input[j][0] >= input[i][0]) {
				
					nextIncludeIndex = j;
					
					break;
				
				}
		    }
			
			maxscores[i] = Math.max(input[i][0] + maxscores[nextIncludeIndex], maxscores[i+1]);
		
		}
		
		
		for(int i=0; i<maxscores.length; i++) {
			
			System.out.println(maxscores[i]);
		}
			
			
			
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
		
		
	
	
	
	
	
	
	
	

}
