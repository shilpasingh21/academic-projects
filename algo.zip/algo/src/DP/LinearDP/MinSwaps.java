package DP.LinearDP;

public class MinSwaps {
	
	
	public static void main(String[] args) {
		
		String input = "111000";
		
		char[] inputarr = input.toCharArray();
		
		int[] swap = new int[inputarr.length];
		
		swap[0] =0;
		
		
		int count_1= 0;
		
		int count_0 =0;
		
		for(int i=0; i<inputarr.length; i++) {
			
			if(inputarr[i] == '1') {
				
				 count_1++;
				
			}
			
			if(inputarr[i] == '0') {
				
				 count_0++;
				
			}
			
		}
		
		if(count_1- count_0 >1) {
			
			System.out.println(-1);
			 
		}
		
		for(int i=1; i<inputarr.length; i++) {
			
			if(inputarr[i] == inputarr[i-1]) {
				
				swap[i] = swap[i-1] > 0 ? swap[i-1] : swap[i-1] +1;
			}
			
			if(inputarr[i] != inputarr[i-1]) {
				
				swap[i] = swap[i-1] > 0 ? swap[i-1]+ 1 : swap[i-1];
			}
			
		}
		
		
		
		
		System.out.println(swap[swap.length-1]);
		
		
		
	}

}
