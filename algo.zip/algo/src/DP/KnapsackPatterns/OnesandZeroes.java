package DP.KnapsackPatterns;

/* You are given an array of binary strings strs and two integers m and n.

Return the size of the largest subset of strs such that there are at most m 0's and n 1's in the subset.*/

/* Input: strs = ["10","0001","111001","1","0"], m = 5, n = 3*/



public class OnesandZeroes {
	
	
	public static void main(String args[]) {
		
		
		String[] input = new String[] {"10","0","1"};
		
		int m = 1;
		
		int n = 1;
		
		int size = getSize(input, m, n, 0);
		
		System.out.println(size);
	}
	
	
	public static int getSize(String[] input, int m, int n, int currentIndex) {
		
		int lastIndex = input.length-1;
		
		if(m ==0) {
			
			return 1;
		}
		
		if( n==0) {
			
			return 1;
		}
		
		if(currentIndex > lastIndex) {
			
			return 0;
		}
		
		int size1= 0;
		
		int size2= 0;
		
		
		int count_0 = (int) input[currentIndex].chars().filter(ch -> ch == '0').count();
		
		
		int count_1 = (int) input[currentIndex].chars().filter(ch -> ch =='1').count();
		
		
		if(count_0 <= m && count_1 <= n) {
			
			size1 = 1 + getSize(input, m-count_0, n-count_1 , currentIndex+1) ;
			
		}
		
		else {
			
			size2 = getSize(input, m, n , currentIndex+1) ;
		}
		
		return Math.max(size1, size2);
		
	}
	
	
}
