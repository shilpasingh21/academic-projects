package DP.KnapsackPatterns;

/*You are a professional robber planning to rob houses along a street. 
Each house has a certain amount of money stashed. All houses at this place are arranged in a circle. 
That means the first house is the neighbor of the last one. Meanwhile, adjacent houses have a security system connected,
and it will automatically contact the police if two adjacent houses were broken into on the same night.

Given an integer array nums representing the amount of money of each house, 
return the maximum amount of money you can rob tonight without alerting the police.*/

public class HouseRobberII {
	
	public static void main(String[] args) { 
		
		int[] input = new int[] {2,3,2};
		
		int profict = getMaxProfit(input);
		
		System.out.println(profict);
		
		
	}
	
	
	public static int getMaxProfit(int[] input) {
		
		int[] profit1 = new int[input.length];
		
		int[] profit2 = new int[input.length];
		
		// Case1: when the first house is not robbed
		
		profit1[0] = 0;
		
		profit1[1] = input[1];
		
		for(int i=2;i<input.length; i++) {
			
			profit1[i] = input[i] + profit1[i-2];
		
		}
		
		int lastIndex = input.length-1;
		
		int max_profit1 = Math.max(profit1[lastIndex], profit1[lastIndex-1]);
		
		
		
		
		// Case2: when the first hose is robbed
		
		profit2[0] = input[0];
		
		profit2[1] = 0;
		
		profit2[input.length-1] =0;
		
		for(int i=2;i<input.length-1; i++) {
			
			profit2[i] = input[i] + profit2[i-2];
		
		}
		
		int max_profit2 = Math.max(profit2[lastIndex], profit2[lastIndex-1]);
		
		
		return Math.max(max_profit1 , max_profit2);
		
		
	}
	
	
}
