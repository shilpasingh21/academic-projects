package DP.Recursion;

public class IntegerBreak {
	
	public static void main(String[] args) {
		
		int input = 10;
		
		int[] numbers = new int[11];
		
		for(int i=1; i<=input; i++) {
			
			numbers[i] = i;
		}
		
		int profit = getMax(numbers, input, 0);
		
		System.out.println(profit);
		
	}
	
	
	public static int getMax(int[] input, int sum, int currentIndex) {
		
		int lastIndex = input.length-1;
		
		
		if(sum==0) {
			
			return 1;
		}
		
		if(currentIndex > lastIndex) {
			
			return 0;
		}
		
		int profit =0;
		
	    int profit1= 0; 
	    
	    int profit2 =0;
		
		if(input[currentIndex] <= sum) {
			
			
			profit1 = Math.max(input[currentIndex] * getMax(input, sum -input[currentIndex] , currentIndex+1), getMax(input, sum , currentIndex+1));
		}
			
		else {
				
			profit2 = getMax(input, sum , currentIndex+1);	
		}
		
		profit = Math.max(profit1, profit2);
		
		return profit;
			
			
		}
		
		
}
