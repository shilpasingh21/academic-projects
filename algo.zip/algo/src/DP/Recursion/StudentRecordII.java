package DP.Recursion;

/* An attendance record for a student can be represented as a string where each character 
 * signifies whether the student was absent, late, or present on that day. The record only contains the following three characters:
 * 'A': Absent.
    'L': Late.
    'P': Present.
 Any student is eligible for an attendance award if they meet both of the following criteria:

    The student was absent ('A') for strictly fewer than 2 days total.
    The student was never late ('L') for 3 or more consecutive days.

Given an integer n, return the number of possible attendance records of length n that make a student eligible for an attendance award. 
The answer may be very large, so return it modulo 109 + 7. */

public class StudentRecordII {
	
	public static void main(String[] args) {
		
		int input = 4;
		
		int total = record(2, 2, 3);
		
		System.out.println(total);
		
	}
	
	
	public static int record(int n, int numberofAbsents, int numberofLateComers) {
		
		if (n==0) {
			
			return 1;
		}
		
		int total = 0;
		
		// If P is selected
		
		total = total + record(n-1, numberofAbsents, numberofLateComers) ;
		
		if(numberofAbsents >0) {
			
			total = total + record(n-1, numberofAbsents-1, numberofLateComers);
			
		}
		
		if(numberofLateComers >0) {
			
			total = total + record(n-1, numberofAbsents, numberofLateComers-1);
		}
		
		return total;
		
		
	}

}
