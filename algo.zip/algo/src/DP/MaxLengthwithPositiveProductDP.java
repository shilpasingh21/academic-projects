package DP;



public class MaxLengthwithPositiveProductDP {
    
	
	public static void main(String[] args) {

        int[] input = new int[] {-1,-2,-3,0,1};

        int length = input.length;

        int[] pos = new int[length];

        int[] neg = new int[length];

        for(int i=0;i<length; i++) {

            pos[i] = 0;
        }

        for(int i=0;i<length; i++) {

            neg[i] = 0;
        }

        if(input[0] > 0) {
                pos[0] = 1;
        }

        if(input[0] < 0) {
                neg[0] = 1;
        }

        int result = 0;

        for(int i=1;i<length; i++) {

            if(input[i] > 0) {
                pos[i] = pos[i-1] + 1;
                neg[i] = neg[i-1] > 0 ?  neg[i-1] + 1: 0;
            }

            if(input[i] <0) {

                pos[i] = neg[i-1] > 0 ?  neg[i-1] + 1: 0;
                neg[i] = pos[i-1] + 1;
            }

            result = Math.max(result,pos[i]);
            
        }

        System.out.println(result);// answer
    }
}