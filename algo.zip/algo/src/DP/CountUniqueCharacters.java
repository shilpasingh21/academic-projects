package DP;

import java.util.*;

// ABA  

public class CountUniqueCharacters {
	
	public static void main(String[] args) {
		
		String input = "CODE";
		
		System.out.println(input.substring(0));
		
		int count = 0;
		
		count = getcountUnique(input);
		
		for(int i=0; i< input.length(); i++) {
			
			String temp = input.substring(i);
			
			System.out.println("temp::" + temp);
			
			int times = i==0? 1:0;
			
			int tempcount = stringcount(temp, times);
			
			count = count + tempcount;
		}
		
		System.out.println("count: " + count);
		
	}
	
	
	public static int stringcount(String input, int times) {
		
		int count =0;
		
		for(int i=0; i<input.length(); i++) {
			
			String left = input.substring(0,i);
			
			System.out.println("left::" + left);
			
			int leftuniquecount = getcountUnique(left);
			
			if(times ==1) {
				
				String right = input.substring(i+1);
			
				System.out.println("right::" + right);
			
				int rightuniquecount = getcountUnique(right);
			
				count = count + leftuniquecount + rightuniquecount;
				
			}
			
			else {
				
				count = count + leftuniquecount;
				
			}
			
		}
		
		return count;
		
	}
	
	
	
	public static int getcountUnique(String s) {
		
		HashSet<Character> set = new HashSet<Character>();
		
		for(int i=0; i<s.length(); i++) {
			
			set.add(s.charAt(i));
		}
		
		return set.size();
		
		
	}
	
	

}
