package DP;

public class GoodDaystoRob {
	
	
	public static void main(String[] args) {
		
		int[] input = new int[] {1,2,3,4,5,6};
		
		int time = 2;
		
		int[] ans = find(input,time);
		
		for(int i=0;i<ans.length;i++) {
		
			System.out.println(ans[i]);
		}
		
		
	}
	
	
	public static int[] find(int[] input, int k) {
		
		boolean leftarrayinclude = false;
		
		boolean rightarrayinclude = false;
		
		
		int[] answer = new int[input.length];
		
		for(int i=0;i<input.length; i++) {
			
			answer[i] = 0;
			
		}
		
		for(int i=0;i<input.length; i++) {
			
			int lastindex = input.length -1;
			
			int afterElements = lastindex - i;
			
			int beforeElemnets = i;
			
			if(afterElements >=k && beforeElemnets >=k) {
				
				leftarrayinclude = checknonincreasing(input, i-k, i-1);
				
				rightarrayinclude = checknondecreasing(input, i+1, i+k);
				
			}
			
			if(leftarrayinclude && rightarrayinclude) {
				
				answer[i] = 1;
			}
		}
		
		return answer;
		
	}
	
	
	public static boolean checknonincreasing(int[] input, int startindex, int lastindex) {
		
		
		for(int i=startindex;i<lastindex; i++) {
			
			if(input[i+1] > input[i]) {
				
				return false;
			}
		}
		
		return true;
		
	}

	
	public static boolean checknondecreasing(int[] input, int startindex, int lastindex) {
		
		for(int i=startindex;i<lastindex; i++) {
			
			if(input[i+1] < input[i]) {
				
				return false;
			}
		}
		
		return true;
	}
			

}

