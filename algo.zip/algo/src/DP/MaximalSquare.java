package DP;

/* Given an m x n binary matrix filled with 0's and 1's, find the largest square containing only 1's and return its area.*/

/* Matrix

10100
10111
11111
10010 */

public class MaximalSquare {
	
	
	public getMaxArea(int[][] matrix) {
		
		int area =0;
	
		for(int i=1; i<matrix.length; i++) {
			
			for(int j=1;j<matrix[0].length; j++) {
				
				if(matrix[i][j] !=0) {
					
					matrix[i][j] = Math.min(matrix[i][j-1], Math.min(matrix[i-1][j], matrix[i-1][j-1])) + 1;
					
					area = Math.max(matrix[i][j],area);
				}
					
				
			}
		}
		
		return area * area;
		
		
	}
	
	
	
}
