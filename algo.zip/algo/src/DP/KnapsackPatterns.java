package DP;

public class KnapsackPatterns {

}
