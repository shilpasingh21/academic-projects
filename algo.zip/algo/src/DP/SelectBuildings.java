package DP;

public class SelectBuildings {
	
	
	
	
	public static void main(String[] args) {
		
		
		int[] input = new int[] {1,1,1,0,0,};
		
		int ans = select(input, 3,0 , -1);
		
		System.out.println(ans);
		
		
		
		
		
		
	}
	
	
	
	public static int select(int[] input, int selection, int currentIndex, int prevVal) {
		
		
		int lastIndex = input.length-1;
		
		int selectReturn =0;
		
		if(selection==0) {
			
			return 1;
		}
		
		if(currentIndex > lastIndex) {
			
			return 0;
		}
		
		if(input[currentIndex] != prevVal) {
			
			selectReturn = select(input, selection-1, currentIndex+1, input[currentIndex])  + select(input, selection, currentIndex+1, prevVal);
		}
		
		else {
			
			selectReturn = select(input, selection, currentIndex+1, prevVal);
		}
		
		return selectReturn;
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	

}
