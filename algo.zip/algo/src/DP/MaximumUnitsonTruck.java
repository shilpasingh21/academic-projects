package DP;

/*You are assigned to put some amount of boxes onto one truck. 
You are given a 2D array boxTypes, where boxTypes[i] = [numberOfBoxesi, numberOfUnitsPerBoxi]:*/

public class MaximumUnitsonTruck {

	public static void main(String[] args) {

		int[] units = new int[] { 3, 2, 1 };

		int[] boxNumbers = new int[] { 1, 2, 3 };

		int trucksize = 4;

		int maxUnit = getMaxUnit(units, boxNumbers, trucksize, 0);

		System.out.println(maxUnit);

	}

	public static int getMaxUnit(int[] units, int[] boxnumbers, int trucksize, int currentIndex) {

		int lastIndex = units.length - 1;

		if (trucksize <= 0 || currentIndex > lastIndex) {

			return 0;
		}

		int maxUnits1 = 0;

		int maxUnits2 = 0;

		
		if (boxnumbers[currentIndex] <= 4) {

			maxUnits1 = units[currentIndex] * boxnumbers[currentIndex]
						+ getMaxUnit(units, boxnumbers, trucksize - boxnumbers[currentIndex], currentIndex + 1);

		   }
		

		maxUnits2 = getMaxUnit(units, boxnumbers, trucksize, currentIndex + 1);

		return Math.max(maxUnits1, maxUnits2);

	}
	
	
	public static int getMaxUnitMemoization(int[][] lookuptable, int[] units, int[] boxnumbers, int trucksize, int currentIndex) {
		
		int lastIndex = units.length - 1;

		if (trucksize <= 0 || currentIndex > lastIndex) {

			return 0;
		}
		
		int maxUnits1 = 0;

		int maxUnits2 = 0;
		
		if(lookuptable[currentIndex][trucksize] !=0) {
			
			return lookuptable[currentIndex][trucksize];
		}
		
		if (boxnumbers[currentIndex] <= 4) {

			maxUnits1 = units[currentIndex] * boxnumbers[currentIndex]
						+ getMaxUnit(units, boxnumbers, trucksize - boxnumbers[currentIndex], currentIndex + 1);
		
		
		}
		
		maxUnits2 = getMaxUnit(units, boxnumbers, trucksize, currentIndex + 1);
		
		lookuptable[currentIndex][trucksize] = Math.max(maxUnits1, maxUnits2);
		
		return lookuptable[currentIndex][trucksize];
		
	}

}
