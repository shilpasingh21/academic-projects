package DP;

// The algo is min(max(left), max(right))  + value at that position --> this is the array

public class TappingRainWater {
	
	
	public static void main(String[] args) {
		
		int[] heights = new int[] {0,1,0,2,1,0,1,3,2,1,2,1};
		
		int left_start = 0;
		
		int left_end = 0;
		
		int right_start = 0;
		
		int right_end = heights.length -1;
		
		int left_max = 0;
		
		int right_max = 0;  
		
		int min = 0;
		
		int[] value = new int[heights.length];
		
		for(int i=0; i<heights.length; i++) {
			
			left_end = i-1;
			
			right_start = i+1;
			
			left_max = getMax(left_start, left_end, heights);
					
			right_max = getMax(right_start, right_end, heights);
			
			if (left_max<=right_max) {
				min = left_max;
			}
			else {
				min = right_max;
			}
			
			value[i] = min - heights[i];
		}
		
		int sum =0;
		
		for(int i=0; i<value.length; i++){
			
			sum = sum + value[i];
		}
			
	}
		
		
		
	public static int getMax(int start, int end, int arr[]) {
		
		
		int last = arr.length -1;
		
		int Max = -999;
		
		if(start ==0 && end <=0) {
			return -1;
		}
		
		if(start ==0 && end ==0) {
			return arr[0];
		}
		
		if(end == last && start > last) {
			return -1;
		}
		
		if(end == last && start == last) {
			return arr[last];
		}
		
		for(int i=start; i<=end; i++) {
			
			if(arr[i] > Max ) {
				Max = arr[i];
			}
		}
		
		return Max;
		
	}
		
}
