package DP;

public class TwoEqualsSubsetMemory {
	
	public static void main(String[] args) {

		int[] input = new int[] { 1, 2, 3, 4 };

		int sum = 0;

		int result;

		for (int i = 0; i < input.length; i++) {

			sum = sum + input[i];
		}
		
		int[][] lookuptable = new int[input.length][sum/2+1];
		
		for(int i =0 ; i<input.length; i++) {
			
			for(int j=0; j <sum/2+1 ; j++) {
				
				lookuptable[i][j] = -1;
			}
			
			
		}

		int sumhalf = sum / 2;

		if (sum % 2 == 0) {

			result = issubsetforsum1(lookuptable, input, sumhalf, 0);
		}

		else {

			result = 0;

		}

		System.out.println(result);

	}
	
	public static int issubsetforsum1(int[][] lookuptable, int[] input, int sum, int currentIndex ) {
		
		if (sum==0) {
			
			return 1;
		}
		
		if(currentIndex >= input.length) {
			
			return 0;
		}
		
		if(lookuptable[currentIndex][sum] == -1) {
			
			
			if(input[currentIndex] <= sum) {
				
				if(issubsetforsum1(lookuptable, input, sum-input[currentIndex], currentIndex+1) == 1) {
					
					lookuptable[currentIndex][sum] = 1;
					
					return 1;
				}
			}
			
			lookuptable[currentIndex][sum] = issubsetforsum1(lookuptable, input, sum, currentIndex+1); 
		}
		
		return lookuptable[currentIndex][sum];
			
			
	}
			
			
}
	
	


