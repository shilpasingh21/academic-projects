package DP;

import java.util.Map;
import java.util.HashMap;

/**
 * You are given an integer array cost where cost[i] is the cost of ith step on
 * a staircase. Once you pay the cost, you can either climb one or two steps.
 * You can either start from the step with index 0, or the step with index 1.
 * Return the minimum cost to reach the top of the floor. Input: cost =
 * [10,15,20] Output: 15 . Explanation: You will start at index 1. Pay 15 and
 * climb two steps to reach the top. The total cost is 15. cost =
 * [1,100,1,1,1,100,1,1,100,1]. The total cost is 6.
 */

public class MinCostClimbingStairs {

	public static void main(String args[]) {

		int[] cost = { 1,100,1,1,1,100,1,1,100,1 };

		Map<Integer, Integer> costmap = findMinCost(cost);
		
		System.out.println(costmap.toString());

	}

	public static Map<Integer, Integer> findMinCost(int[] cost) {

		Map<Integer, Integer> costmap = new HashMap<Integer, Integer>();

		int costnew;

		int lastindex = cost.length - 1;

		for (int i = cost.length - 1; i >= 0; i--) {

			if (i == lastindex || i == lastindex - 1) {
				costmap.put(i, cost[i]);
			}

			else {
				costnew = Math.min(cost[i] + costmap.get(i + 1), cost[i] + costmap.get(i + 2));
				costmap.put(i, costnew);
			}

		}

		return costmap;
	}
	
	

}
