package Tree;

public class Traverse {

	class Node {

		int data;

		Node leftNode;

		Node rightNode;

		Node(int data) {

			this.data = data;

			leftNode = null;

			rightNode = null;
		}
	}

	private Node root;

	public Node getRoot() {
		return root;
	}

	public void setRoot(Node root) {

		this.root = root;

	}

	// Iterative function to insert a value in BST

	public boolean add(int value) {

		if (this.root == null) {

			Node newNode = new Node(value);

			this.root = newNode;

			return true;
		}

		Node current = root;

		while (current != null) {

			if (value > current.data) {

				// Right subtree

				if (current.rightNode == null) {

					Node newNode = new Node(value);

					current.rightNode = newNode;

					return true;

				}

				current = current.rightNode;

			}

			else if (value <= current.data) {

				// Left subtree

				if (current.leftNode == null) {

					Node newNode = new Node(value);

					current.leftNode = newNode;

					return true;
				}

				current = current.leftNode;

			}

		}

		return false;
	}

}
