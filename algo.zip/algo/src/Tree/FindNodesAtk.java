package Tree;

public class FindNodesAtk {
	
	
	public findNodes(Node current, int value) {
		
		if(current == null) {
			
			return -1;
		}
		
		if(value == k) {
			
			return list
		}
		
		else {
			
			findNodes(current.left)
		}
	}

}
