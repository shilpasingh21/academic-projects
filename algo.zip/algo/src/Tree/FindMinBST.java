package Tree;

import Tree.DeleteBST.Node;

public class FindMinBST {
	
	class Node {
		
		int data;
		
		Node leftChild;
		
		Node rightChild;
	}
	
	
	
	public Node findMin( Node root) {
		
		if (root ==null) {
			
			return null;
		}
		
		Node current = root;
		
		while(current.leftchild !=null) {
			
			current = current.leftchild l
			
			
		}
		
		return curret.data;
	}
	
	
	public static void main(String[] args) {
		
		
	}
	
	
	
	

}
