package Tree;

public class FindHeight {
	
	public int findHeight(Node current) {
		
		if(current ==  null) {
			
			return -1;
		}
		
		int height=  1 + Max(findHeight(current.left), findHeight(current.right));
		
		return height;
		
		
		
	}
	
	

}
