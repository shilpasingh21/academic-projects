package Tree;

import java.util.ArrayList;

import Tree.DeleteBST.Node;

/* Given the root to a Binary Search Tree and a node value "k", write a function to find the ancestor of that node. */

public class FindAncestors {
	
	public findAncestor(Node root, int value) {
		
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		if (root == null) {
			
			return null;
		}
		
		Node current = root;
		
		while(current!=null) {
			
			if(current.data == value) {
				return
			}
			else if(value < current.data) {
				
				list.add(current.data);
				
				current = current.leftChild;
				
			}
			
			else if(value > current.data) {
				
				list.add(current.data);
				
				current = current.rightchild;
				
			}
			
		}
		
		
		
		
		
		
	}
	
	
	
	
	
	
	

}
