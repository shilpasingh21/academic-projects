package Tree;

import java.util.ArrayList;

/* Given the root to a binary search tree--a number "k"--write a function to find the kth maximum value in that tree. */

public class FindKMaxinBST {
	
	
	ArrayList<Integer> list = new ArrayList<Integer>();
	
	
	public void inorder(Node current) {
		
		if(current == null) {
			
			return;
		}
		
		inorder(current.leftchild);
		
		list.add(current.data);
		
		inorder(current.rightchild);
		
		
	}
	
	public static void main(String[] args) {
		
		inorder(root);
		
		Kmax = list.get(list.size() -1);
		
		return Kmax;
	}

}
