package Tree;

public class DeleteBST {
	
	Node root;
	
	class Node {
		
		int data;
		
		Node leftChild;
		
		Node rightChild;
		
		Node(int data) {
			
			this.data = data;
			
			this.leftChild = null;
			
			this.rightChild = null;
			
		}
	}
	
	
	public boolean deleteNode(int value) {
		
		if(this.root == null ){
			
			return false;
		}
		
		Node current = this.root;
		
		Node parent = null;
		
		while(current!=null || current.data == value) {
			
			parent = current;
			
			if(value > current.data) {
				
				current = current.rightChild;
			}
			
			else if( value < current.data) {
				
				current = current.leftChild;
			}
		}
		
		if(current!=null) {
			return false;
		}
		
		if (current.leftChild ==  null && current.rightChild == null) {
			
			if(current.data <= parent.data) {
				
				parent.leftChild = null;
				
				return true;
			}
			
			else if(current.data > parent.data) {
				
				parent.rightChild = null;
				
				return true;
			}
			
			
		}
		
		
		if((current.leftChild !=null || current.rightchild !=null ) {
			
			
			if(current.data > parent.data) {
				
				parent.rightChild = 
			}
		
		
			
			
				
				
			
			
				
				
				
				
			
			
			
			
		}
	}
	
	
	

}
