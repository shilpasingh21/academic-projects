package Tree;

public class SearchBST {
	
	
	class Node {
		
		int data;
		Node leftChild;;
		Node rightchild;
		
		Node( int value) {
			
			this.data = value;
			
			this.leftChild = null;
			
			this.rightchild = null;
		}
		
	}
	
	Node root;
	
	public Node search(int value) {
		
		if(root == null) {
			
			return null;
		}
		
		Node current = root;
		
		
		while(current!=null) {
			
			if(current.data == value) {
				
				return current;
			}
			
			else if(value > current.data) {
				
				current = current.rightchild;
			}
			
			else if(value < current.data) {
				
				current = current.leftChild;
				
			}
		}
		
		return null;
		
		
	}
	
}
