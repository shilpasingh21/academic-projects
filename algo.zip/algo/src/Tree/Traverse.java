package Tree;

import Tree.DeleteBST.Node;

public class Traverse {
	
	
	public void preorderTraverse(Node current) {
		
		if(current ==  null ) {
			
			return;
		}
		
		System.out.println(current.data);
		
		preorderTraverse(current.leftChild);
		
		preorderTraverse(current.rightChild);
		
		
	}
	
	public void inorderTraverse(Node current) {
		
		if(current ==  null ) {
			
			return;
		}
		
		
		inorderTraverse(current.leftChild);
		
		System.out.println(current.data);
		
		inorderTraverse(current.rightChild);
		
		
	}
	
	public void postOrderTraverse(Node current) {
		
		if(current ==  null ) {
			
			return;
		}
		
		
		postOrderTraverse(current.leftChild);
		
		postOrderTraverse(current.rightChild);
		
		System.out.println(current.data);
		
		
	}
	
	
}
