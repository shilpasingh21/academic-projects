package OOAD;

public class ChessGame {

}
