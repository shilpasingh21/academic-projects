package OOAD;

public class VendingMachine {

}
