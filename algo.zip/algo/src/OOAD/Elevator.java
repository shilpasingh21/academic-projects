package OOAD;

public class Elevator {

}
