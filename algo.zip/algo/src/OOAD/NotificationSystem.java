package OOAD;

public class NotificationSystem {

}
