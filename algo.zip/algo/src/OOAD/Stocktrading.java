package OOAD;

public class Stocktrading {

}
