package OOAD;

public class ParkingLot {
	
	

}
