package OOAD;

public class AmazonLocker {

}
