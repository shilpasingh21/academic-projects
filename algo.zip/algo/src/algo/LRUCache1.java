package algo;

import java.util.*;



public class LRUCache1 {
	
	private Map<Integer,Integer> map = new HashMap<Integer,Integer>();
	
	private Queue<Integer>  queue = new LinkedList<Integer>();
	
	int capacity;
	

	public void put(Integer key, Integer value) {
		
		if(map.size() == capacity) {
			
			Integer last = queue.remove();
			
			map.remove(last);
		}
		
		map.put(key, value);
		
		queue.add(key);
		
		capacity = map.size() == capacity ? capacity : map.size();
	}
	
	
	public Integer get(Integer key) {
		
		if(map.containsKey(key)) {
			
			return map.get(key);
		}
		
		else {
			
			return null;
		}
		
		
	}
	
	
	
}
