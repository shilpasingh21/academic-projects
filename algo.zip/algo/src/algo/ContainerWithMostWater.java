package algo;

public class ContainerWithMostWater {

	public static void main(String args[]) {

		int[] height = { 1, 8, 6, 2, 5, 4, 8, 3, 7 };

		int maxvol = findMaxVolume(height);

		System.out.println(maxvol);

	}

	public static int findMaxVolume(int[] container) {

		int[] maxinfo = findMaxindex(container);

		int maxvol = Integer.MIN_VALUE;

		int maxindex = maxinfo[0];
		
		System.out.println("maxindex::" + maxindex);

		int curr_vol = 0;

		for (int i = maxindex+1, j = 1; i < container.length; i++, j++) {

			curr_vol = j * container[i];

			if (curr_vol > maxvol) {
				maxvol = curr_vol;
			}
		}

		return maxvol;

	}

	public static int[] findMaxindex(int[] container) {

		int max = Integer.MIN_VALUE;

		int maxindex = -1;

		int[] returnVal = { -1, -1 };

		for (int i = 0; i < container.length; i++) {

			if (container[i] > max) {

				max = container[i];

				maxindex = i;
			}

		}

		returnVal[0] = maxindex;

		returnVal[1] = max;

		return returnVal;

	}

}
