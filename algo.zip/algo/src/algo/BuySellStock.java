package algo;

public class BuySellStock {
	
	public static void main(String args[]) {
		
		int[] prices = {5,6,7,4,2,8,3};
		
		int profit = buysell(prices);
		
		System.out.println(profit);
	}
	
	
	public static int buysell(int[] prices) {
		
		int lastindex = prices.length-1;
		
		int MAX = Integer.MAX_VALUE;
		
		int MIN = Integer.MIN_VALUE;
		
		int minindex = 0;
		
		int maxindex =0;
		
		
		for(int i=lastindex; i>=0; i--)  {
			
			if(prices[i] < MAX) {
				
				MAX = prices[i];
				minindex = i;
				
			}
		}
		
		if (minindex < lastindex) {
			
		   for(int i= minindex; i<=lastindex; i++) {
				
				if(prices[i] > MIN) {
					MIN = prices[i];
					maxindex = i;
					
				}
			}
			
			return prices[maxindex] - prices[minindex];
		}
		
		else {
			return 0;
		}
		
	}

}
