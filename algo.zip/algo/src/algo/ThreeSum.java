package algo;


import java.util.Map;
import java.util.HashMap;


public class ThreeSum {
	
	public static void main(String args[]) {
		
		int[] nums = {0,1,1};
		int[] ret = ThreeSum(nums) ;
		
		for(int i=0;i<ret.length; i++) {
			
			System.out.println(ret[i]);
		}
	}
	
	public static int[] ThreeSum(int[] nums) {
		
		Map<Integer,Integer> nums1 = new HashMap<Integer,Integer>();
		
		int[] ret = {-1,-1,-1};
		
		for(int i=0;i<nums.length; i++) {
			
			nums1.put(nums[i], i);
		}
		
		for(Map.Entry<Integer,Integer> entry: nums1.entrySet()) {
			
			int num1 = entry.getKey();
			
			int targetsum = -num1;
			
			int[] getindex = TwoSum(targetsum,nums1);
					
			if (getindex[0] != -1 && getindex[0] != entry.getValue() && getindex[1] != entry.getValue()) {
				
				ret[0] = getindex[0];
				
				ret[1] = getindex[1];
				
				ret[2] = entry.getValue();
				
			}
		 } 
			
	    return ret;
	}
	
	
	public static int[] TwoSum(int targetsum, Map<Integer,Integer>nums1) {
		
		int[] ret = {-1,-1};
		
		for(Map.Entry<Integer,Integer> entry: nums1.entrySet()) {
			
			int curr = entry.getKey();
			
			int currindex = entry.getValue();
			
			int diff = targetsum - curr;
			
			if(nums1.containsKey(diff)) {
				
				if(nums1.get(diff) != currindex) {
					
					ret[0] = currindex;
					ret[1] = nums1.get(diff);
				}
			}
			
		}
		
		return  ret;
	}
	
}
