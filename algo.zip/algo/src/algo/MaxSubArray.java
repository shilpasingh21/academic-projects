package algo;

public class MaxSubArray {
	
	public static void main(String args[]) {
		
	}
	
	public static int maxSubArray(int[] nums) {
		
		if(nums.length == 0 || nums == null) {
			return 0;
		}
		
		int current_sum = nums[0];
		int max = nums[0];
		
		for(int i=1; i<nums.length; i++) {
			
			current_sum = Math.max(current_sum, nums[i] + current_sum);
			max =  Math.max(max,current_sum);
		}
		
		return max;
	}
	
}
