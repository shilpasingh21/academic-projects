package algo;

import java.util.*;


/** Given an array of strings strs, group the anagrams together. You can return the answer in any order.

An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, 
typically using all the original letters exactly once. **/

public class GroupAnagrams {
	
  String[] inputs = new String[]{"eat","tea","tan","ate","nat","bat"};
  
  HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
  
  ArrayList<ArrayList<String>> output = new ArrayList<ArrayList<String>>();
  
  
  for(int i=0; i<inputs.length; i++) {
	  
	  String sortedword = Collections.sort(inputs[i]);
	  
	  if(map.contains(sortedword)) { 
		  
		  ArrayList<String> list = map.get(sortedword);
		  
		  list.add(inputs[i]);
	  }
	  
	  else {
		  
		  ArrayList<String> list = new ArrayList<String>();
		  
		  list.add(inputs[i]);
		  
		  map.put(sortedword, list);
	  }
	  
  }
  
  
  for(Map.Entry<String, ArrayList<String>> entry: map.entryset()) {
	  
	  ArrayList<String> list = entry.getValue();
	  
	  output.add(list);
	  
  }
  
  
  
  
  
  
  
  
  
	
	
	
	

}
