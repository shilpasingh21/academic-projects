package algo;

import java.util.Map;
import java.util.HashMap;



public class FindDuplicate {
	
	public static void main(String arg[]) {
		
		int[] nums = {1,2,3,4,5,6,7,8,9,10};
		
		System.out.println(findDuplicate(nums));
		
		
		
	}
	
	
	public static boolean findDuplicate(int[] nums) {
		
		Map<Integer,Integer> map1 = new HashMap<Integer,Integer>();
		
		int current;
		
		for(int i=0;i<nums.length; i++) {
			
			current = nums[i];
			
			int val = map1.containsKey(current) ? map1.get(current) + 1 : 1;
			
			map1.put(nums[i], val);
			
		}
		
		for (Map.Entry<Integer, Integer> entry: map1.entrySet()) {
			
			int ret = map1.get(entry.getValue());
			
			if (ret > 1) 
				return true;
		}
		
		return false;
	}

}
