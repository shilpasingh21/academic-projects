package algo;

import java.util.*;

public class FileSystem {
	
	private class FileNode {
		
		private Map<String, FileNode> children;
		
		private boolean isFile;
		
		private String content;
		
		FileNode(boolean isFile) {
			
			this.isFile = isFile;
			
			this.children = new HashMap<String, FileNode>();
			
			
			
		}
		
	}
	
	FileNode root;
	
	FileSystem() {
		
		root = new FileNode(false);
	}
	
	
	
	public mkdir(String path) {
		
		String[] subdirs = path.split("/");
		
		FileNode current = root;
		
		for(int i=1; i<subdirs.length; i++) {
			
			String subdir = subdirs[i];
			
			if(current.children.containsKey(subdir)) {
				
				current = current.children.get(subdir);
				
				continue;
			}
			
			
			FileNode newNode = new FileNode(false);
			
			current.children.put(subdir, newNode);
			
			current = newNode;
		}
			
	}
	
	
	public writeContent(String path , String content) {
		
		String[] subdirs = path.split("/");
		
		FileNode current = root;
		
		for(int i=1; i<subdirs.length; i++) {
			
			String subdir = subdirs[i];
			
			if(current.children.containsKey(subdir)) {
				
				current = current.children.get(subdir);
				
				continue;
			}
			
			FileNode newNode = new FileNode(false);
			
			current.children.put(subdir, newNode);
			
			current = newNode;
			
		}
		
		current.content = content;
	
	}
	
	
	
	public ls(String path) {
		
		
	     String[] subdirs = path.split("/");
	     
	     FileNode current = root;
	     
	     for(int i=0 ;i<subdirs.length; i++) {
	    	 
	    	 String subdir = subdirs[i];
	    	 
	    	 if(current.children.containsKey(subdir)) {
	    		 
	    		 crrent = current.children.containsKey(subdir)
	    	}
	    	 
	     }
	     
	     resullist;
	     
	     if(current.isFile) {
	    	 
	    	 resultlist.add(path);
	    	 
	    	 else {
	    		 
	    		 from current map , get all the keys
	    		 
	    		 
	    	 }
	    	 
	    	 
	     
	     
	    	 
	    	 
	    	 
	    	 
	    	 
	    	 
	    	 
	    	 
	     }
	     
	     
		
		
	}




}
	
	
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	


