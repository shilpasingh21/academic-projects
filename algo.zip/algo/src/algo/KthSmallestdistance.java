package algo;

import java.util.*;

public class KthSmallestdistance {
	
   static private class Pair {
		
		Integer x;
		Integer y;
		
		Pair(Integer x, Integer y) {
			
			this.y = y;
			this.x = x;
		}
	}
	
	
	
	static Map<Integer,ArrayList<Pair>> map = new TreeMap<Integer,ArrayList<Pair>>();
	
	
	public static Integer getDistance(List<Integer> input, Integer k) {  
		
		for(int i=0; i<input.size()-1; i++ ) {
			
			for(int j = i+1; j< input.size() ;j++) {
				
				int diff = Math.abs(input.get(i) - input.get(j));
				
				if (map.containsKey(diff)) {
					
					ArrayList<Pair> list = map.get(diff);
					
					list.add(new Pair(input.get(i),input.get(j)));
					
				}
				
				else {
					
					ArrayList<Pair> list = new ArrayList<Pair>();
					
					list.add(new Pair(input.get(i),input.get(j)));
					
					map.put(diff, list);
				}
			}
			
		}
		
		int temp =1;
		
		
		for(Integer key: map.keySet() ) {
			
			temp ++;
			
			if(temp == k) {
				
				return key;
			
			}
			
		}
		
		return null;
		
		
	}
	
	
	
	public static void main(String args[]) {
		
		
		List<Integer> input = new ArrayList<Integer>(List.of(1,3,1));
		
		Integer dist = getDistance(input, 1);
		
		System.out.println(dist);
		
	}
	
	
}
