package algo;

import java.util.LinkedList;

import algo.Islands.Pair;

public class NumberOfProvinces {
	
	
	public static int getProvince() {
	
		private int[][] matrix = new int[][] {
		{1,1,0},
		{1,1,0},
		{0,0,1}
		};
		
		boolean visited[][] = new boolean[3][3];
		
		int count =0;
		
		
		for(int i=0; i<matrix.length; i++){
			
			for(int j=0; j<matrix[0].length; j++]) {
				
				if(!visited[i][j]) {
					
					count++;
					
					bfs(i,j,visited, matrix);
				}
				
			}
		}
		
		
		return count;
	}
	
	
	public static void bfs(int x, int y, visited, matrix) {
		
	
		int[] x_dir = {0,1,0,-1};
		
		int[] y_dir = {1,0,-1,0};
		
		LinkedList<Pair> queue = new LinkedList<Pair>();
		
		queue.add(new Pair(x,y));
		
	    while(!queue.isempty()) {
	    	
	    	cur_elem = queue.remove();
	    	
	    	visisted[i][j] = true;
	    	
	    	for(int i=0; i<x_dir.length; i++) {
	    		
	    		x_new = x + x_dir[i];
	    		
	    		y_new = x+ y_dir[i];
	    		
	    		if(X-new withing limits nad y_ne wwithinh limit and value at this == 1)
	    		
	    		queue.add(new Pair(x_new, y_new));
	    		
	    	}
	    }
			
	}
	
			
			
			
			
			
			
			
			
			
	
			
	
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	

}
