package algo;

import java.util.*;

public class ConcatenatedWords {
	
	
	public static void main(String[] args) {
		
		
		Set<String> dict = new HashSet<String>(List.of("cat","dog","catdog"));
		
		List<String> input = new ArrayList<String>(List.of("cat","dog","catdog"));
		
		List<String> ans = new ArrayList<String>();
		
		
		for (int i=0; i<input.size(); i++) {
			
			String word = input.get(i);
			
			if(subpart(word, dict)) {
				
				ans.add(word);
			}
			
			
		}
		
		System.out.println(ans.size());
		
		for(int i=0;i<ans.size(); i++) {
			
			System.out.println(ans.get(i));
			
			
		}
	}
	
	
	public static boolean subpart(String word, Set<String> dict) {
		
		for(int i=1; i<word.length(); i++) {
			
			String leftpart = word.substring(0,i);
			
			String rightpart = word.substring(i);
			
			if (dict.contains(leftpart)) {
				
				return true;
			}
			
			if (dict.contains(rightpart)) {
				
				return true;
			}
			
			
			if(subpart(rightpart,dict)) {
				
				return true;
			}
			
		}
		
		return false;
		
	}
}
