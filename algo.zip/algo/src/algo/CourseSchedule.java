package algo;

import java.util.*;

public class CourseSchedule {
	
	public static void main(String[] args) {
		
		int[][] input = new int [][] {
			
			{1,0},
			{1,0}
		};
		
		
		List<LinkedList<Integer>> adjList = new ArrayList<LinkedList<Integer>>();
		
		for(int i=0; i<input.length; i++) {
			
			for(int j= 0; j<input[0].length; j++) {
				
				int first = input[i][1];
				
				int second = input[i][0];
				
				LinkedList<Integer> list = new LinkedList<Integer>();
				
				list.add(second);
				
				adjList.add(first, list);
				
			}
			
		}
		
		
	   Queue<Integer> queue = new LinkedList<Integer>();
	   
	   Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	   
	   queue.add(input[0][1]);
	   
	   int courses =0;
	   
	   while(!queue.isEmpty()) {
		   
		   int cur = queue.remove();
		   
		   map.put(cur,cur);
		   
		   if(map.containsKey(adjList.get(cur).get(0))) {
			   
			   return false;
		   }
		   
		   else {
			   
			   courses ++;
			   
			   queue.add(adjList.get(cur).get(0));
		   }
	   }
	   
	   return true;
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
	   }
		
		
		 
		
		
		
		
		
		
		
		
	}
			
	
	

}
