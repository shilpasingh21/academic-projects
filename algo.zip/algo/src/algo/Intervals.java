package algo;

import java.util.*;

//[1, 3] [ 2, 5] . Interval class will return 1 when they are overlapping. will return -11 if they are disjoint.

public class Interval implements Comparable<Interval> { 
	
	private final Integer start_t;
	
	private final Integer end_t;
	
	public Interval(Integer start_t, Integer end_t){
		
		this.start_t = start_t;
		
		this.end_t = end_t;
		
	}
	
	public int compareTo(Interval other) {
		
		if(this.end_t > other.start_t) {
			return 1; // overlapping
		}
		
		else if (this.end_t < other.start_t) {
			return -1; // disjoint
			
		}
		else {
			return 0;
		}
			
	}
	
	
	public class IntervalCollection {
		
		private Map<Interval, Interval> sortedMap = new TreeMap<Interval, Interval>();
		
		
		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
