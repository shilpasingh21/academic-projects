package algo;

import java.util.*;

public class MedianFinder {

	private PriorityQueue<Integer> minHeap;

	private PriorityQueue<Integer> maxHeap;

	public MedianFinder() {

		this.minHeap = new PriorityQueue<Integer>();

		this.maxHeap = new PriorityQueue<Integer>(Collections.reverseOrder());

	}

	public void add(int num) {

		int temp = 0;
		
		if(maxHeap.isEmpty()) {
			
			maxHeap.add(num);
			
			return;
			
		}
		
		int maxleft = maxHeap.peek();
		
		if(num > maxleft) {
			
			minHeap.add(num);
			
		}
		
		else {
			
			maxHeap.add(num);
			
		}

		while (Math.abs(maxHeap.size() - minHeap.size()) > 1) {
			
			if(maxHeap.size() > minHeap.size()) {
				
				temp = maxHeap.poll();
				
				minHeap.add(temp);
			}
			
			else {
				
				temp = minHeap.poll();

				maxHeap.add(temp);
			}
				
		}

	}

	public float findMedian() {

		int median;

		int maxHeapsize = maxHeap.size();

		int minHeapsize = minHeap.size();

		if (maxHeapsize == minHeapsize) {

			int first = maxHeap.poll();

			int second = minHeap.poll();

			median = (first + second) / 2;

		}

		else if (maxHeapsize > minHeapsize) {

			median = maxHeap.poll();

		}
		
		else {
			
			median = minHeap.poll();
		}

		return median;

	}
	
	
	
	public static void main(String[] args) {
		
		MedianFinder medianfinder = new MedianFinder();
		
		medianfinder.add(1);
		
		medianfinder.add(5);
		
		medianfinder.add(10);
		
		medianfinder.add(2);
		
		medianfinder.add(2);
		
		medianfinder.add(0);
		
		medianfinder.add(11);
		
		medianfinder.add(7);
		
		medianfinder.add(7);
		
		System.out.println(medianfinder.findMedian());
		
		
		
		
		
	}

}
