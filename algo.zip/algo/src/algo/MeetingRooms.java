package algo;


import java.util.*;

/** Given an array of meeting time intervals intervals where intervals[i] = [start, end], 
 * return the minimum number of conference rooms required.
 */

public class MeetingRooms {
	
	public static void main(String[] args ) {
		
		List<ArrayList<Integer>> input = new ArrayList<ArrayList<Integer>>();
		
		Map<ArrayList<Integer>,Integer>  map = new HashMap<ArrayList<Integer>, Integer>();
		
		for(int i=0 ;i<input.size(); i++) {
			
			if(map.isEmpty()) {
				
				map.put(input.get(i), 1);
				
			}
			
			else {
				
				for(Map.Entry<ArrayList<Integer>,Integer> entry:  map.entrySet()) {
					
					if (isDisJoint(entry.getKey(),input.get(i));
					
					exit;
					
					
				}
			}
			
			
		
		
		}
	 
		
	}
	
	
	
	
	public static boolean isDisJoint(ArrayList<Integer> key, ArrayList<Integer> source) {
		
		int key_x = key.get(0);
		
		int key_y = key.get(1);
		
		int source_x = source.get(0);
		
		int source_y = source.get(1);
		
		if (source_x >= key_y || key_x >= source_y) {
			
			return true;
		}
		
		else {
			
			return false;
		}
		
		
		
		
		
		
		
		
		
		
	
	
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
