package algo;

import java.util.*;

public class OverlappingTopics {
	
	public static void main(String[] args) {
		
		String[] inputA = new String[] {"corona", "petrol", "climate", "cricket", "climate", "corona", "soccer", "music", "submarine", "elections"};
	
		String[] inputB = new String[] { "corona","climate"};
		
		int K = inputB.length;
		
		for(int i=0, j = K-1; j<inputA.length ;i++, j++) {
			
			if(findOverlap(i, j, inputA, inputB)) {
				
				System.out.println("found");
				
			}
		}
		
		System.out.println("Not found");
	}
		
		
		public static boolean findOverlap(int start, int end, String[] dict,String[] arr2) {
			
			Set<String> set = new HashSet<String>();
			
			for( int i=start; i<=end ; i++) {
				
				set.add(dict[i]);
			}
			
			for(int i=0; i<arr2.length; i++) {
				
				if(!set.contains(arr2[i])) {
					
					return false;
				}
			}
			
			return true;
		}
			
 }
