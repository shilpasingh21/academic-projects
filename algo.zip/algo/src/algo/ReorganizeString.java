package algo;

import java.util.HashMap;
import java.util.*;

public class ReorganizeString {
	
	
	public static String rearrange(String input) {
		
		char[] chars = input.toCharArray();
		
		Map<Character,Integer> countMap = new HashMap<Character,Integer>();
		
		for(int i=0;i<chars.length; i++) {
			
			countMap.put(chars[i], countMap.getOrDefault(chars[i], 0) + 1);
		}
		
		System.out.println(countMap.values());
		
		System.out.println(countMap.keySet());
		
		PriorityQueue<Character> queue = new PriorityQueue<Character>((a,b) ->  countMap.get(b) - countMap.get(a));
		
		queue.addAll(countMap.keySet());
		
		StringBuilder answer = new StringBuilder();
		
		
		while(!queue.isEmpty() && queue.size() >=2) {
			
			Character max = queue.poll();
			
			Character next = queue.poll();
			
			answer.append(max);
			
			answer.append(next);
			
			countMap.put(max, countMap.get(max) -1);
			
			countMap.put(next, countMap.get(next) -1);
			
			int newMaxCount =  countMap.get(max);
			
			int newNextCount =  countMap.get(next);
			
			if(newMaxCount > 0) {
				queue.add(max);
			}
			
			if(newNextCount > 0) {
				queue.add(next);
			}
			
		}
		
		if (queue.size() == 1) {
			
			Character last = queue.poll();
			
			answer.append(last);
			
		}
		
		return answer.toString();
		
	}
	
	
	public static void main(String[] args) {
		
		String inputString = "aab";
				
		String newString = rearrange(inputString);
		
		System.out.println(newString);
		
		
	}
	
	
	
	
	
}
