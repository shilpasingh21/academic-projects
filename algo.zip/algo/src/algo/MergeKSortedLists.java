package algo;

import java.util.*;

/* You are given an array of k linked-lists lists, each linked-list is sorted in ascending order.

Merge all the linked-lists into one sorted linked-list and return it.*/

public class MergeKSortedLists {
	
	
	static PriorityQueue<Integer> queue = new PriorityQueue<Integer>();
	
	static Map<Integer,Integer> map = new HashMap<Integer, Integer>();
	
	static LinkedList<Integer> answer = new LinkedList<Integer>();
	
	
	public static void merge(ArrayList<LinkedList<Integer>> input) {
		
		// Initializing the queue and map
		
		for(int i=0; i<input.size(); i++) {
			
			LinkedList<Integer> list = input.get(i);
			
		    Integer first = list.getFirst();
		    
		    map.put(i, first);
		    
		    queue.add(first);
		    
		}
		
		// Loop to merge
		
		
		while(!queue.isEmpty()) {
			
			Integer min_element = queue.poll();
			
			answer.add(min_element);
			
			//loop through the map and update the first for the list whose element is removed
			
			for(Map.Entry<Integer,Integer> entry: map.entrySet()) {
				
				Integer listindex = entry.getKey();
				
				Integer first = entry.getValue();
				
				if (first == min_element) {
					
					LinkedList<Integer> list = input.get(listindex);
					
					if(!list.isEmpty()) {
					
						list.remove(first);
					
						Integer new_first = list.getFirst();
					
						map.put(listindex, new_first);
						
						queue.add(new_first);
				    }
				
					else {
					
					  map.remove(listindex);
					
					}
				}
			}
		}
		
		
		
			
			
			
			
			
			
		
		
		
		
		
		
		    
		    
		    
		    
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	

}
