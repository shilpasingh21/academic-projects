package algo;

import java.util.HashSet;

public class CountUniqueCharacatersofAllSubstring {
	
	
	public static void main(String[] args) {
		
		String given = "LEETCODE";
		
		int maxcount =given.length();
		
		for(int i=0;i<given.length(); i++) {
			
			String input = given.substring(i);
			
			maxcount = maxcount + getcount(input, i);
			
		}
		
		System.out.println(maxcount);
		
	}
	
		
	public static int getcount(String input, int index) {
		
		
		int count = 0;
		
		for(int i=1;i<input.length(); i++) {
			
			if(index==0) {
			
				String left = input.substring(0,i);
			
				String right = input.substring(i);
			
				char[] leftarray = left.toCharArray();
			
				char[] rightarray = right.toCharArray();
			
				HashSet<Character> leftSet = new HashSet<Character>();
			
				HashSet<Character> rightSet = new HashSet<Character>();
			
				for(char x : leftarray) {
				
					leftSet.add(x);
				
				}
			
				for(char x : rightarray) {
				
					rightSet.add(x);
				
				}
			
			
				count = count + leftSet.size() + rightSet.size();
			}
			
			else {
				
				String left = input.substring(0,i);
				
				char[] leftarray = left.toCharArray();
				
				HashSet<Character> leftSet = new HashSet<Character>();
				
				for(char x : leftarray) {
					
					leftSet.add(x);
				
				}
				
				count = count + leftSet.size();
				
			}
		}
		
		return count;
		
		
	}
	
	
	
	
	
	

}
