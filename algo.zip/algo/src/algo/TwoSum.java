package algo;

import java.util.Map;
import java.util.HashMap;



class TwoSum {
    public static void main(String[] args) {
        int[] nums = {999,1,11,9};
        int target = 1000;
        int[] result = getSumOptimal(nums,target);
        System.out.println(result[0]);
        System.out.println(result[1]);
        
    }
    
    public static int[] getSum(int[] nums, int target) {
        int[] ans = {0,0};
        for(int i=0, j=i+1;j<nums.length;j++) {
            if(nums[i] + nums[j] == target) {
                 ans[0] = i;
                 ans[1] = j;
                 return ans;
            }
        }
        return ans;
    
    }
    
    public static int[] getSumOptimal(int[] nums, int target) {
    	
    	Map<Integer,Integer> numberMap = new HashMap<Integer,Integer>();
    	
    	int result[] = {0,0};
    	
    	for(int i=0; i<nums.length; i++) {
    		numberMap.put(nums[i],i);
    	}
    	
    	for (Integer first: numberMap.keySet()) {
    		
        	Integer second = target  - first;
        	
        	if(numberMap.containsKey(second)) {
        		
        		result[0]= numberMap.get(first);
        		result[1]= numberMap.get(second);
        		return result;
        	}
        }
        
        return result;
    }
}
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        
    	
    	
    	
    	
    	
    	
    	
    	
   	
   
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    
    
