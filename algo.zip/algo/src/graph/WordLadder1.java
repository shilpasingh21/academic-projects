package graph;

import java.util.*;

// "hit, cog"

public class WordLadder1 {
	
	
	public class Element {
		
		String word;
		
		int level;
		
		Element(String word, int level) {
			
			this.word = word;
			this.level = level;
		}
		
	}

	
	public static int getLevel() {
		                               X     X       X     X     X
		String[] dict = new String[] {"hot","dot","dog","lot","log","cog"};
		
		String start = "hit";
		
		String end = "cog";
		
		int level = 0;
		
		LinkedList<Element> queue = new LinkedList<Element>();
		
		queue.add(new Element(start,level)); //  cofg |4 dog|3   log|3  dot|2, lot|2    |hot,1    |hit,0 
		
		while(!queue.isEmpty()) {
			
			Element cur  = queue.remove();
			
			if(cur.word == end) {
				return cur.level;
			}
			
			for(int i=0; i<dict.length; i++) {
			
				if(getdist(cur.word, dict[i]) == 1) {
					
					queue.add(new Element(dict[i], cur.level + 1));
					dict.remove(i);
				}
					
			}
		}
		
	}
	
	
	
	public static int getdist(String str1, String str2) {
		
		char[] char1 = str1.toCharArray();
		
		char[] char2 = str2.toCharArray();
		
		int count =0;
		
		
		for(int i=0; i<char1.length; i++) {
			
			if(char1[i] != char2[i]) {
				
				count++;
			}
		}
		
		return count;
			
	}

}
