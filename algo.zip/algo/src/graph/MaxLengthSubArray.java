package graph;

import java.util.*;

public class MaxLengthSubArray {
	
	
	public static void main(String[] args) {
		
		int[] input = new int[] {0,1,-2,-3,-4};
		
		int[] result = new int[input.length]; 
		
		int maxLength = maxLengthSubArray(input, result) + 1;
		
		System.out.println(maxLength);
		
		
	}
		
		
	public static int maxLengthSubArray(int[] input, int[] result) {
		
		result[0] = input[0];
		
		for(int i=1 ;i<input.length;i++) {
			
			result[i] = Math.max(result[i-1] * input[i], input[i]);
		}
		
		
		for(int i=result.length-1; i>=0; i--) {
			
			if(result[i] >0) {
				
				return i;
			}
		}
		
		return -1;
		
	}
			
}
