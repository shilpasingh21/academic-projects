package graph;

import java.util.LinkedList;
import java.util.Queue;

/*Given two words, beginWord and endWord, and a dictionary wordList, 
return the number of words in the shortest transformation sequence 
from beginWord to endWord, or 0 if no such sequence exists.*/

/*Example 1:

Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
Output: 5
Explanation: One shortest transformation sequence is "hit" -> "hot" -> "dot" -> "dog" -> cog", which is 5 words long.*/

public class WordLadder {
	
	public static void main(String args[]) {
		
		String[] wordList = new String[]{"hot","dot","dog","lot","log","cog"};
		
		String beginword = "hit"; 
		
		String endword = "cog"; 
		
		int level = getLevel(beginword, endword, wordList);
		
		System.out.println("level is :" + level);
		
	}
	
	
	public static int hammingDistance(String str1, String str2) {
		
		char[] chr1 = str1.toCharArray();
		
		char[] chr2 = str2.toCharArray();
		
		int count=0;
		
		for(int i=0;i<chr1.length; i++)  {
			if(chr1[i] != chr2[i]) {
				count++;
			}
		}
		
		return count;
	}
	
	
	public static int getLevel(String beginword, String endword, String[] wordList) {
		
		Queue<String> queue = new LinkedList<>();
		
		queue.add(beginword);
		
		int level = 0;
		
		while(!queue.isEmpty()) {
			
			String cur_element = queue.remove();
			
			level ++;
			
			for(int i=0; i<wordList.length; i++) {
				
				if(hammingDistance(cur_element, wordList[i]) == 1) {
					
					queue.add(wordList[i]);
					
					if(wordList[i] == endword) {
						return level;
					
				    }
				}
			}
			
		}
		
		return 0;
	}
	
}
