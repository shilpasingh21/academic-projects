package graph;

import java.util.LinkedList;
import java.util.Queue;



public class RottenOrange {
	
	
	static class PairR{
		
		int x;
		int y;
		int level;
		
		PairR(int x, int y, int level) {
			
			this.x = x;
			this.y = y;
			this.level = level;
			
		}
	}
	
	public  static void main(String[] args) {
		
		
		int[][] input = new int[][] {
			{2, 1, 1},
			{1, 1, 0},
			{0, 1, 1}
		};
		
		int rows = input.length;
		
		int cols = input[0].length;
		
		boolean[][] visited = new boolean[rows][cols];
		
		for(int i=0;i<rows;i++) {
			
			for(int j=0;j<cols;j++) {
				
				visited[i][j] = false;
			}
		}
		
		for(int i=0;i<rows; i++) {
			
			for(int j=0;j< cols;j++) {
				
				if(visited[i][j] == false && input[i][j] == 2) {
				
					int level = bfs(i, j, visited, input, rows, cols);
			    }
				
		   }
	   }
	}
	
	
	public static int bfs(int row, int col, boolean[][] visited, int[][] input, int rows, int columns) {
		
		int[] dir_x = new int[] { -1,0, 1,0};
		
		int[] dir_y = new int[] { 0,-1, 0, 1};
		
		Queue<PairR> queue = new LinkedList<>();
		
		int level = 0;
		
		queue.add(new PairR(row, col,level));
		
		while(!queue.isEmpty()) {
			
			if (queue.size() ==1) {
				
				PairR pair = queue.remove();
				
				return pair.level;
			}
			
			PairR pair = queue.remove();
			
			int x = pair.x;
			
			int y = pair.y;
			
			visited[x][y] = true;
			
			input[x][y] = 2;
			
			for(int i=0;i< dir_x.length; i++) {
			
				int new_x = x + dir_x[i];
			
				int new_y = y + dir_y[i];
				
				int new_level = pair.level +1;
				
				if(new_x < rows && new_x >=0 && new_y < columns && new_y >=0 && 
						visited[new_x][new_y] == false && input[new_x][new_y] ==1) {
					
					queue.add(new PairR(new_x, new_y, new_level));
					
					
				}
					
			}
		}
		
		
	}
		
		
}
			
			
		
		
		
	


