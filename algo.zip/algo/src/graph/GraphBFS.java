package graph;
import java.io.*;
import java.util.*;

public class GraphBFS {
    private int vertices;
    private List<LinkedList<Integer>> adjList= new ArrayList<LinkedList<Integer>>();

    GraphBFS(int v){
        vertices = v;
        for (int i=0;i<v;i++) {
            LinkedList<Integer> adj = new LinkedList<Integer>();
            adjList.add(i, adj);
        }
    }

    public void addEdge(int v, int w){
        adjList.get(v).add(w);
    }

    public void bfsTravel(int s){
    	
        LinkedList<Integer> queue = new LinkedList<Integer>();
        Boolean[] visited = new Boolean[this.vertices];
        visited[s] = true;
        queue.add(s);

        while(!queue.isEmpty()){
            int current_element = queue.poll();
            System.out.println("current element is " + current_element);
            LinkedList<Integer> curr_list = this.adjList.get(current_element);
            Iterator<Integer> indexItr = curr_list.iterator();
            while(indexItr.hasNext()) {
            	int element = indexItr.next();
                if (visited[element] == null) {
                    visited[element] = true;
                    queue.add(element);
                }

            }

        }

    }
    
    public void bfsTravelDisconnected() {
    	Boolean[] visited = new Boolean[this.vertices];
    	ArrayList<LinkedList<Integer>> adjList = new ArrayList<LinkedList<Integer>>();
    	LinkedList<Integer> output = new LinkedList<Integer>();
    	
    	for (int i=0; i<this.vertices; i++) {
    		if (visited[i] == false) {
    			visited[i] = true;
    			LinkedList<Integer> queue = new LinkedList<Integer>();
    			queue.add(i);
    			while(!queue.isEmpty()) {
    				int element = queue.poll();
    				LinkedList<Integer> cur_list = adjList.get(element);
    				Iterator<Integer> iterator = cur_list.iterator();
    				while(iterator.hasNext()) {
    					int cur_element = iterator.next();
    					if (visited[cur_element] == false) {
    						visited[cur_element] = true;
    						System.out.println(cur_element);
    						queue.add(cur_element);
    						
    					}
    				}
    			}
    		}
    	}
    						
    }
    					
    				
    				
    				
    public static void main(String args[]) {

       GraphBFS graph  = new GraphBFS(4);
       graph.addEdge(0,1);
       graph.addEdge(0,2);
       graph.addEdge(1,2);
       graph.addEdge(2,0);
       graph.addEdge(2,3);
       graph.addEdge(3,3);

       System.out.println("Printing bfs travel");

       graph.bfsTravel(2);

    }


}