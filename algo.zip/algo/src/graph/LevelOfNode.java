package graph;
import java.io.*;
import java.util.*;

import org.w3c.dom.Node;

// Find the Shortest path between 2 nodes:


	public class GraphBFS {
    
	private int vertices;
    private List<LinkedList<Integer>> adjList= new ArrayList<LinkedList<Integer>>();

    GraphBFS(int v){
        vertices = v;
        for (int i=0;i<v;i++) {
            LinkedList<Integer> adj = new LinkedList<Integer>();
            adjList.add(i, adj);
        }
    }

   
    public void addEdge(int v, int w){
        adjList.get(v).add(w);
    }
    
    
    public int getmin(int source, int destination) {
    		
    	Queue<Integer> queue = new Queue<Integer>();
    	
    	queue.add(source);
    	
    	int count = 0;
    	
    	int[] level  = new int[vertices];
    	
    	level[source] = count;
    	
    	boolean[] visited = new boolean[vertices];
    	
    	visited[source] =true;
    		
    	while(!queue.isEmpty()) {
    		
    		int cur = queue.dequeu();
    		
    		LinkedList<Integer> list =adjlist[cur];
    		
    		Node cur = list.head();
    		
    		count++;
    		
    		while(cur !=null) {
    			
    			if(visited[cur.data] == false) {
    					
    				visited[cur.data] = true;
    				
    				queue.enqueue(cur.data);
    				
    				level[cur.data] = count;
    				
    				if(cur.data == destination) {
    					return count;
    				}
    				
    		    }
    			
    			cur = cur.next;
    	   }
    	}
    	
    	return -1;
    		
    }
    
    
    public int getmax(int source, int destination) {
		
    	Queue<Integer> queue = new Queue<Integer>();
    	
    	queue.add(source);
    	
    	int count = 0;
    	
    	Map<Integer,Integer> level = new HashMap<Integer>();
    	
    	level.put(source,count);
    	
    	boolean[] visited = new boolean[vertices];
    	
    	visited[source] =true;
    		
    	while(!queue.isEmpty()) {
    		
    		int cur = queue.dequeu();
    		
    		LinkedList<Integer> list =adjlist[cur];
    		
    		Node cur = list.head();
    		
    		count++;
    		
    		while(cur !=null) {
    			
    			if(visited[cur.data] == false) {
    					
    				visited[cur.data] = true;
    				
    				queue.enqueue(cur.data);
    				
    				level.put(cur.data,count);
    				
    			 }
    			
    			cur = cur.next;
    	   }
    	}
    	
    	if(level.containsKey(destination)) {
    		return level.get(destination);
    	}
    	else {
    		return -1;
    	}
    	
    }
	
}
