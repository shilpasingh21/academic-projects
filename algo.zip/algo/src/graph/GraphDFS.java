package graph;
import java.io.*;
import java.util.*;

public class GraphDFS {
    private int vertices;
    private List<LinkedList<Integer>> adjList= new ArrayList<LinkedList<Integer>>();

    GraphDFS(int v){
        vertices = v;
        for (int i=0;i<v;i++) {
            LinkedList<Integer> adj = new LinkedList<Integer>();
            adjList.add(i, adj);
        }
    }

    public void addEdge(int v, int w){
        adjList.get(v).add(w);
    }

    public void dfsTravel(int s){
    	LinkedList<Integer> stack = new LinkedList<Integer>();
    	boolean[] visited = new boolean[this.vertices];
    	visited[s] = true;
    	stack.add(s);
    	
    	while(!stack.isEmpty()) {
    		Integer cur_element= stack.pop();
    		System.out.println("current element is " + cur_element);
    		LinkedList<Integer> cur_list = this.adjList.get(cur_element);
    		Iterator<Integer> itr = cur_list.iterator();
    		while(itr.hasNext()) {
    			Integer element = itr.next();
    			visited[element] = true;
    			stack.add(element);
    		}
    		
    	}
    	
    }

    public static void main(String args[]) {

       GraphDFS graph  = new GraphDFS(4);
       graph.addEdge(0,1);
       graph.addEdge(0,2);
       graph.addEdge(1,2);
       graph.addEdge(2,0);
       graph.addEdge(2,3);
       graph.addEdge(3,3);

       System.out.println("Printing bfs travel");

       graph.dfsTravel(2);

    }


}