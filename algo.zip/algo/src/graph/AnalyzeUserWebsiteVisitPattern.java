package graph;

import java.util.*;

public class AnalyzeUserWebsiteVisitPattern {

	public static void main(String[] args) {

		String[] website = new String[] { "home", "about", "career", "home", "cart", "maps", "home", "home", "about",
				"career" };

		String[] username = new String[] { "joe", "joe", "joe", "james", "james", "james", "james", "mary", "mary",
				"mary" };

		int[] timestamp = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		Map<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

		Set<String> users = new HashSet<String>();

		for (int i = 0; i < username.length; i++) {

			users.add(username[i]);
		}

		for (String user : users) {

			List<String> userwebsite = new ArrayList<String>();

			for (int i = 0; i < username.length; i++) {

				if (username[i] == user) {

					userwebsite.add(website[i]);
				}
			}

			for (int i = 0; i < userwebsite.size(); i++) {

				for (int j = i + 1; j < userwebsite.size(); j++) {

					for (int k = j + 1; k < userwebsite.size(); k++) {

						String tuple = new String(userwebsite.get(i) + ","+ userwebsite.get(j) + "," + userwebsite.get(k));

						if (map.containsKey(tuple)) {

							ArrayList<String> list = map.get(tuple);

							if (!list.contains(user)) {

								list.add(user);
							}
						}

						else {

							ArrayList<String> list = new ArrayList<String>();

							list.add(user);

							map.put(tuple, list);
						}

					}
				}
			}

		}
		
		for(Map.Entry<String, ArrayList<String>> entry: map.entrySet()) {
			
			System.out.println(entry.getKey() + " " + entry.getValue().toString());
		}
		
		
		
		
		int Max = -9999;
		
		String tuple = null;
		
		for(Map.Entry<String, ArrayList<String>> entry: map.entrySet()) {
			
			int count = entry.getValue().size();
			
			if(count  > Max ) {
				
				Max = count;
				
				tuple = entry.getKey();
			}
		}
		
		System.out.println(tuple.toString());
		
		  

	}

}
