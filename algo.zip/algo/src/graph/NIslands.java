package graph;

import java.util.*;

public class NIslands {

	public static class Pair {

		int x;
		int y;

		Pair(int inputx, int inputy) {
			x = inputx;
			y = inputy;
		}
	}

	public static void islands(int[][] grid, int row, int col, boolean[][] visited) {

		int rowlen = grid[0].length;

		int collen = grid.length;

		int[] x_co = new int[] { -1, 0, 1, 0 };

		int[] y_co = new int[] { 0, -1, 0, 1 };

		LinkedList<Pair> queue = new LinkedList<Pair>();

		Pair cur_el = new Pair(row, col);

		queue.add(cur_el);

		while (!queue.isEmpty()) {

			Pair cur_element = queue.remove();

			int rowx = cur_element.x;

			int colx = cur_element.y;

			visited[rowx][colx] = true;

			for (int i = 0; i < x_co.length; i++) {

				int newrow = rowx + x_co[i];

				int newcol = colx + y_co[i];

				if (newrow < rowlen && newcol < collen && newrow >= 0 && newcol >= 0 && grid[newrow][newcol] == 1 
						&& visited[newrow][newcol] == false) {
					queue.add(new Pair(newrow, newcol));
				}
			}
		}
	}

	public static void main(String[] args) {

		int[][] grid = new int[][] { { 1, 1, 0}, { 1, 1, 0}, { 0, 0, 1 } };

		int islandcount = 0;

		int rowlen = grid[0].length;

		int collen = grid.length;

		boolean[][] visited = new boolean[rowlen][collen];
		
		for (int i = 0; i < collen; i++) {
			for (int j = 0; j < rowlen; j++) {
				visited[i][j]=  false;
			}
		}

		for (int i = 0; i < collen; i++) {
			for (int j = 0; j < rowlen; j++) {
				
				if(!visited[i][j] && grid[i][j] == 1) {
					islandcount++;
					islands(grid, j, i, visited);
				}
			}
		}

		System.out.println("No of island::" + islandcount);

	}

}
