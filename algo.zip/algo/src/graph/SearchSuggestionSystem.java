package graph;

import java.util.*;

public class SearchSuggestionSystem {

	public static void main(String[] args) {

		String[] products = new String[] { "mobile", "mouse", "moneypot", "monitor", "mousepad" };

		Arrays.sort(products);

		Map<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

		String serachWord = "mouse";

		for (int i = 0; i <= serachWord.length(); i++) {

			String subString = serachWord.substring(0, i);

			ArrayList<String> list = new ArrayList<String>();

			for (String word : products) {

				if (word.startsWith(subString) && list.size() <= 3) {

					list.add(word);
				}
			}
			
			map.put(subString, list);
		}
		
		
		for(Map.Entry<String, ArrayList<String>> entry: map.entrySet()) {
			
			System.out.println(entry.getKey() + " "+ entry.getValue());
			
		}
		
	}

}
