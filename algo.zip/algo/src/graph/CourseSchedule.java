package graph;

import java.util.*;

import org.w3c.dom.Node;

/* There are a total of numCourses courses you have to take, labeled from 0 to numCourses - 1. 
 * You are given an array prerequisites where prerequisites[i] = [ai, bi] indicates that you must take course bi 
 * first if you want to take course ai. For example, the pair [0, 1], indicates that to take course 0 you have to 
 * first take course 1.Return true if you can finish all courses. Otherwise, return false.
 */

/*Example 1:

Input: numCourses = 2, prerequisites = [[1,0]]
Output: true
Explanation: There are a total of 2 courses to take. 
To take course 1 you should have finished course 0. So it is possible. */

/* Example 2:

Input: numCourses = 2, prerequisites = [[1,0],[0,1]]
Output: false
Explanation: There are a total of 2 courses to take. 
To take course 1 you should have finished course 0, and to take course 0 you should also have finished course 1.
So it is impossible. */



public class CourseSchedule {
	
	class Graph {
		 int vertices;
		 List<LinkedList<Integer>> adjList = new ArrayList<LinkedList<Integer>>();
	}
	
	public HashSet<Integer> set = new HashSet<Integer>();
	
	public Graph createGraph(ArrayList<ArrayList<Integer>> courses) {
		
		Graph graph = new Graph();
		
		for(int i=0; i<courses.size(); i++) {
			
			int first = courses.get(i).get(0);
			
			int second = courses.get(i).get(1);
			
			set.add(first);
			
			set.add(second);
			
			LinkedList<Integer> list = new LinkedList<Integer>();
			
			list.add(first);
			
			graph.adjList.add(second, list);
			
			graph.vertices = set.size();
			
			return graph;
		}
	}
	
	public boolean isCycle(Graph graph, int source, boolean[] visited, boolean[] stacked) {
		
		
		if(visited[source] == true) {
			return false ;
		}
		
		if(stacked[source] == true) {
			return true ;
		}
		
		visited[source] = true;
		stacked[source] = true;
		
		LinkedList<Integer> list = graph.adjList.get(source);
		
		Node current = list.head;
		
		while(current !=null) {
			
			if(isCycle(graph,source,visited, stacked)) {
				
				return true;
				
			}
			
			current = current.getNext();
		}
		
		stacked[source] =false;
		
		return false;
	}
	
	
	public static void main(String[] args) {
		
		ArrayList<ArrayList<Integer>> courses = new ArrayList<ArrayList<Integer>>() {{1,0},{0,1}};
		
		int coursesno = 5;
		
		 boolean[] visited = new boolean[];
		 
		 boolean[] stacked= new boolean[];
		 
		 boolean possible = true;
		
		Graph graph = createGraph(courses); 
		
		for (int i=0; i<graph.vertices; i++) {
			
			if(isCycle(graph, i, visited, stacked)) {
				
				possible = false;
			}
		}
		
		
		if(possible) & set.size()  <= coursesno) {
			return true;
		}
		else {
			return false;
		}
	}
}
			
			
			
			
			
			
		
		
		
		
		
		
	