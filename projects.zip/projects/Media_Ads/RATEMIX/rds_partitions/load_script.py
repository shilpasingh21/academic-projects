import logging
import boto3
import sys
import json
from py4j.java_gateway import java_import
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pg8000.native import Connection
from botocore.exceptions import ClientError
from datetime import datetime, timedelta
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DateType, DecimalType

sql_file_map = {
    'impressions_aggregate_non_search': 'ETL/SQL/impressions_aggregate_non_search.sql',
    'impressions_aggregate_search': 'ETL/SQL/impressions_aggregate_search.sql',
    'impressions_monthly': 'ETL/SQL/impressions_monthly.sql',
    'traffic_aggregate': 'ETL/SQL/traffic_aggregate.sql',
    'traffic_monthly': 'ETL/SQL/traffic_monthly.sql',
    'widget_aggregate': 'ETL/SQL/widget_aggregate.sql',
    'widget_monthly': 'ETL/SQL/widget_monthly.sql'
}

s3_location_of_datafiles = {
    'impressions_aggregate_search': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_impressions_aggregates_search',
    'impressions_aggregate_non_search': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_impressions_aggregates_non_search',
    'impressions_monthly': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_impressions_monthly',
    'traffic_aggregate': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_traffic_aggregates',
    'traffic_monthly': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_traffic_monthly',
    'widget_aggregate': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_widget_aggregates',
    'widget_monthly': 's3://mwaa-output-prod-858176756051/ratemix_aggregates/ratemix_widget_monthly'
}

s3_client = boto3.client('s3')
s3_bucket = 'aws-glue-scripts-301006281812-us-east-1'
secret_name = 'RdsStackProdUSEAST1Database-keG3gZ2ippjL'
rds_connection = 'RDSConnection'
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def parse_args(argv):
    argument_list = ['JOB_NAME']
    if '--{}'.format('PARTITION_DATE') in sys.argv:
        argument_list.append('PARTITION_DATE')
    if '--{}'.format('EXECUTION_DATE') in sys.argv:
        argument_list.append('EXECUTION_DATE')
    if '--{}'.format('DATASET_NAME') in sys.argv:
        argument_list.append('DATASET_NAME')

    arguments = getResolvedOptions(argv, argument_list)
    if 'PARTITION_DATE' not in arguments:
        raise Exception("PARTITION_DATE missing in the input parameters to the RDS Load Job")
    if 'DATASET_NAME' not in arguments:
        raise Exception("DATASET_NAME missing in the input parameters to the RDS Load Job")
    return arguments


def get_db_credentials():
    session = boto3.session.Session()
    secret_client = session.client(
        service_name='secretsmanager',
        region_name='us-east-1'
    )
    try:
        if not secret_name:
            raise ValueError("Secret name parameter to get_db_credentials is not initialized.")
        get_secret_api_response = secret_client.get_secret_value(SecretId=secret_name)
        if 'SecretString' in get_secret_api_response:
            secret = get_secret_api_response['SecretString']
        elif 'SecretBinary' in get_secret_api_response:
            secret = base64.b64decode(get_secret_value_response['SecretBinary'])
        else:
            raise ValueError("Secret not fetched from the secret api response.")
        secret_json = json.loads(secret)
        return secret_json
    except ClientError as err:
        if err.response.get('Error', {}).get('Code') == 'DecryptionFailureException':
            logger.error("Secrets Manager can't decrypt the protected secret text using the provided KMS key")
        elif err.response.get('Error', {}).get('Code') == 'InternalServiceErrorException':
            logger.error("An error occurred on the server side")
        elif err.response.get('Error', {}).get('Code') == 'InvalidParameterException':
            logger.error("An invalid value for a parameter was provided")
        elif err.response.get('Error', {}).get('Code') == 'InvalidRequestException':
            logger.error("Provided a parameter value that is not valid for the current state of the resource")
        elif err.response.get('Error', {}).get('Code') == 'ResourceNotFoundException':
            logger.error("Can't find the resource being asked for")
        raise err
    except Exception as err:
        logger.error("------ Exception while retrieving secret---- " + str(err))
        raise err


def get_rds_db_connection():
    print("Getting the secret details from the secret manager.")
    secret_json = get_db_credentials()
    print("Getting the database credentials and host information from the secret json.")
    username = secret_json.get("username")
    password = secret_json.get("password")
    host = secret_json.get("host")
    port = secret_json.get("port")
    print("Creating Aurora RDS connection using pg8000 driver..")
    try:
        connection_rds = Connection(
            database='postgres',
            user=username,
            password=password,
            host=host,
            port=port
        )
        print(f"Connection successful with RDS Aurora postgres db")
    except Exception as err:
        print(f"Unable to connect with RDS Aurora postgres db with Exception: {err}")
        raise err
    return connection_rds


def read_data_from_s3_using_spark(dataset_name, partition_date, table_schema):
    print(f"Reading {dataset_name} data for {partition_date} from S3")
    input_data_file = s3_location_of_datafiles.get(dataset_name)
    s3_path = f"{input_data_file}/partition_date={partition_date}/"
    input_df = spark.read.format("csv").option("header", "false").schema(table_schema).load(s3_path)
    input_df_count = input_df.count()
    print(f"Number of records read for dataset {dataset_name} for date {partition_date} are {input_df_count}")
    return input_df


def get_glue_connection_info():
    glue_client = boto3.client('glue', 'us-east-1')
    try:
        connection_response = glue_client.get_connection(Name=rds_connection)
    except ClientError as client_error:
        if client_error.response['Error']['Code'] == 'EntityNotFoundException':
            error_message = 'No glue connection found for RDSConnection'
            print(error_message)
            raise client_error
        else:
            raise client_error
    else:
        connection_properties = connection_response['Connection']
        return connection_properties


def get_connection_properties(glue_connection, table_name):
    connection_properties = {
        "url": glue_connection['ConnectionProperties']['JDBC_CONNECTION_URL'],
        "user": glue_connection['ConnectionProperties']['USERNAME'],
        "password": glue_connection['ConnectionProperties']['PASSWORD'],
        "dbtable": table_name,
        "database": "postgres"
    }
    return connection_properties


def write_spark_data_frame_to_rds(input_df, table_name):
    glue_connection = get_glue_connection_info()
    connection_properties = get_connection_properties(glue_connection, table_name)
    try:
        print(f"Started writing the spark data frame to RDS Aurora")
        input_df.write.format("jdbc")\
            .mode("overwrite")\
            .option("url", connection_properties.get('url')) \
            .option("dbtable", connection_properties.get('dbtable')) \
            .option("user", connection_properties.get('user')) \
            .option("password", connection_properties.get('password'))\
            .option("truncate", True)\
            .option("numPartitions",10)\
            .save()
        print(f"Successfully completed writing data for all files to RDS Aurora")
    except Exception as err:
        print(f"Exception raised while writing Spark data frame to RDS is {err}")
        raise err


def get_sql_file_from_s3(dataset_name):
    s3_files_prefix = 'ETL/SQL'
    file_list = []
    s3_objects = s3_client.list_objects_v2(Bucket=s3_bucket, Prefix=s3_files_prefix)
    if 'Contents' in s3_objects:
        objs = s3_objects['Contents']
        file_list = [obj['Key'] for obj in objs]
    sql_file_for_dataset = sql_file_map.get(dataset_name)
    if sql_file_for_dataset in file_list:
        print(f"The sql code file is retrieved from S3 location for the dataset {dataset_name}")
    else:
        raise Exception(f"The sql code file is not present in S3 for the dataset {dataset_name}")
    return sql_file_for_dataset


def get_s3_file_content(file_key):
    s3_key_object = s3_client.get_object(Bucket=s3_bucket, Key=file_key)
    s3_file_content = s3_key_object['Body'].read().decode("utf-8")
    print(f"S3 file content fetched for the file {s3_file_content}")
    return s3_file_content


def execute_ddl_for_dataset(file_key, partition_date_str):
    print(f"Executing DDls for date {partition_date_str}")
    connection = get_rds_db_connection()
    s3_file_content = get_s3_file_content(file_key)
    query_commands = s3_file_content.split(";")
    for query in query_commands:
        query = query.rstrip('\n').lstrip('\n')
        query = query.replace('{PERIOD}', partition_date_str)
        if query:
            print(f"Running the below sql query defined in file {file_key} in database: {query}")
            connection.run(query)
            print(f"Successfully executed the query in the database.")
    connection.close()
    print(f"Executed all the DDls in the file {file_key}")


def get_schema_map_for_dataframe(file_key):
    print("Deriving schema for spark data frame.")
    s3_file_content = get_s3_file_content(file_key)
    columns_str = s3_file_content.split(";")[0].split("(", 1)[1].split(") PARTITION")[0]
    columns_list = columns_str.split(",")
    columns_map = dict()
    for col in columns_list:
        col_name = col.strip().split(" ")[0]
        col_data_type = col.strip().split(" ")[1]
        if 'bigint' in col_data_type:
            spark_data_type = LongType()
        elif 'varchar' in col_data_type:
            spark_data_type = StringType()
        elif 'int' in col_data_type:
            spark_data_type = IntegerType()
        elif 'date' in col_data_type:
            spark_data_type = DateType()
        elif 'numeric' in col_data_type:
            spark_data_type = DecimalType()
        else:
            print("Spark Data type not found for schema mapping.")
        columns_map[col_name] = spark_data_type
    struct_list = list()
    for key, value in columns_map.items():
        struct_list.append(StructField(key, value))
    dest_schema = StructType(struct_list)
    print("Schema is derived for spark data frame.")
    return dest_schema


def create_reporting_schema():
    print("Creating schema for ratemix data sets if it does not exist.")
    connection = get_rds_db_connection()
    query = "CREATE SCHEMA IF NOT EXISTS ratemix;"
    connection.run(query)
    connection.close()


def attach_partition_to_main_table(partition_date, dataset_name, partition_table_name):
    format = '%Y-%m-%d'
    partition_date_upper = (datetime.strptime(partition_date, format).date() + timedelta(days=32)).replace(day=1)
    partition_date_upper_str = str(partition_date_upper)
    print(f"Attaching the new partition for {partition_date} to the main table")
    connection = get_rds_db_connection()
    query = f"ALTER TABLE ratemix.{dataset_name} ATTACH PARTITION {partition_table_name} " \
            f"FOR VALUES FROM ('{partition_date}') TO ('{partition_date_upper_str}');"
    print(f"Attach partition ddl is : {query}")
    connection.run(query)
    print(f"New partition for {partition_date} is attached to the main table.")
    connection.close()


# Main Function
sc = SparkContext.getOrCreate()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
args = parse_args(sys.argv)
glue_job = Job(glue_context)
dataset_name = args.get('DATASET_NAME')
partition_date = args.get('PARTITION_DATE')
if args.get('EXECUTION_DATE'):
    execution_date = args.get('EXECUTION_DATE')
    print(f"The execution date passed as parameter to the job is {execution_date}")
partition_date_str = partition_date.replace("-", "")
partition_table_name = f'ratemix.{dataset_name}_{partition_date_str}'
print(f"Starting load job for {dataset_name}.")
glue_job.init(args.get('JOB_NAME', 'RDSRatemixLoadJob'), args)
java_import(spark._jvm, 'org.postgresql.Driver')
create_reporting_schema()
file_key = get_sql_file_from_s3(dataset_name)
dest_schema = get_schema_map_for_dataframe(file_key)
execute_ddl_for_dataset(file_key, partition_date_str)
input_df = read_data_from_s3_using_spark(dataset_name, partition_date, dest_schema)
input_df.printSchema()
write_spark_data_frame_to_rds(input_df, partition_table_name)
attach_partition_to_main_table(partition_date, dataset_name, partition_table_name)
print(f"RDS Load job completed for {dataset_name} for date {partition_date}.")
