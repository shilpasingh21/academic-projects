CREATE TABLE IF NOT EXISTS ratemix.impressions_aggregate_search(
partition_date date,
year integer,
month integer,
period varchar(90),
device_type varchar(50000),
page_layout varchar(50000),
page_type varchar(50000),
placement_slot varchar(50000),
marketplace_id bigint,
impressions numeric,
revenue numeric,
page_request_with_ads numeric
) PARTITION BY RANGE (partition_date);


DROP TABLE IF EXISTS ratemix.impressions_aggregate_search_{PERIOD};

CREATE TABLE IF NOT EXISTS ratemix.impressions_aggregate_search_{PERIOD}(
partition_date date,
year integer,
month integer,
period varchar(90),
device_type varchar(50000),
page_layout varchar(50000),
page_type varchar(50000),
placement_slot varchar(50000),
marketplace_id bigint,
impressions numeric,
revenue numeric,
page_request_with_ads numeric
);

CREATE INDEX IF NOT EXISTS IMPRESSIONS_AGG1_{PERIOD}_IDX1 ON ratemix.impressions_aggregate_search_{PERIOD}(marketplace_id);

CREATE INDEX IF NOT EXISTS IMPRESSIONS_AGG1_{PERIOD}_IDX2 ON ratemix.impressions_aggregate_search_{PERIOD}(page_type);

CREATE INDEX IF NOT EXISTS IMPRESSIONS_AGG1_{PERIOD}_IDX3 ON ratemix.impressions_aggregate_search_{PERIOD}(partition_date);