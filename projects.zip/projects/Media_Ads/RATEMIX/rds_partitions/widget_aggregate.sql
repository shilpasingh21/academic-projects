CREATE TABLE IF NOT EXISTS ratemix.widget_aggregate(
	partition_date date,
	month integer,
	year integer,
	period varchar(90),
	device varchar(1000),
	page_layout varchar(1000),
	page_type varchar(1000),
	placement_slot varchar(1000),
	marketplace_id bigint,
	total_widget_requests bigint,
	filled_widget_requests bigint,
	valid_revenue_widget numeric,
	valid_impression_widget bigint,
	total_impression_widget bigint
	) PARTITION BY RANGE (partition_date);


DROP TABLE IF EXISTS ratemix.widget_aggregate_{PERIOD};

CREATE TABLE IF NOT EXISTS ratemix.widget_aggregate_{PERIOD}(
	partition_date date,
	month integer,
	year integer,
	period varchar(90),
	device varchar(1000),
	page_layout varchar(1000),
	page_type varchar(1000),
	placement_slot varchar(1000),
	marketplace_id bigint,
	total_widget_requests bigint,
	filled_widget_requests bigint,
	valid_revenue_widget numeric,
	valid_impression_widget bigint,
	total_impression_widget bigint
);

CREATE INDEX IF NOT EXISTS WIDGET_AGG2_{PERIOD}_IDX1 ON ratemix.widget_aggregate_{PERIOD}(marketplace_id);

CREATE INDEX IF NOT EXISTS WIDGET_AGG2_{PERIOD}_IDX2 ON ratemix.widget_aggregate_{PERIOD}(page_type);

CREATE INDEX IF NOT EXISTS WIDGET_AGG2_{PERIOD}_IDX3 ON ratemix.widget_aggregate_{PERIOD}(partition_date);