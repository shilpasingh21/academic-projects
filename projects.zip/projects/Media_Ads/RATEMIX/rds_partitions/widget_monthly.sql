CREATE TABLE IF NOT EXISTS ratemix.widget_monthly(
	partition_date date,
	month integer,
	year integer,
	period varchar(90),
	marketplace_id bigint,
	device varchar(1000),
	page_type varchar(1000),
	tq_valid_placement varchar(1000),
	page_number varchar(1000),
	page_layout varchar(1000),
	placement_slot varchar(1000),
	pl varchar(1000),
	total_widget_requests bigint,
	filled_widget_requests bigint,
	valid_impression_widget bigint,
	total_impression_widget bigint,
	total_revenue_widget numeric,
	valid_revenue_widget numeric,
	total_clicks_widget bigint
) PARTITION BY RANGE (partition_date);


DROP TABLE IF EXISTS ratemix.widget_monthly_{PERIOD};

CREATE TABLE IF NOT EXISTS ratemix.widget_monthly_{PERIOD}(
	partition_date date,
	month integer,
	year integer,
	period varchar(90),
	marketplace_id bigint,
	device varchar(1000),
	page_type varchar(1000),
	tq_valid_placement varchar(1000),
	page_number varchar(1000),
	page_layout varchar(1000),
	placement_slot varchar(1000),
	pl varchar(1000),
	total_widget_requests bigint,
	filled_widget_requests bigint,
	valid_impression_widget bigint,
	total_impression_widget bigint,
	total_revenue_widget numeric,
	valid_revenue_widget numeric,
	total_clicks_widget bigint
);

CREATE INDEX IF NOT EXISTS WIDGET_AGG1_{PERIOD}_IDX1 ON ratemix.widget_monthly_{PERIOD}(marketplace_id);

CREATE INDEX IF NOT EXISTS WIDGET_AGG1_{PERIOD}_IDX2 ON ratemix.widget_monthly_{PERIOD}(page_type);

CREATE INDEX IF NOT EXISTS WIDGET_AGG1_{PERIOD}_IDX3 ON ratemix.widget_monthly_{PERIOD}(partition_date);