CREATE TABLE IF NOT EXISTS ratemix.impressions_monthly(
partition_date date,
year integer,
month integer,
period varchar(90),
marketplace_id bigint,
currency_code varchar(50000),
device_type varchar(50000),
page_type varchar(50000),
page_layout varchar(50000),
placement_slot varchar(50000),
impression_index varchar(50000),
page_number varchar(50000),
dominant_gl_group varchar(50000),
no_of_source_ads varchar(50000),
country_of_origin varchar(36),
merchant_type varchar(36),
prime_type integer,
bid_bucket_usd varchar(50000),
impressions bigint,
clicks bigint,
cost_local numeric,
revenue numeric
) PARTITION BY RANGE (partition_date);


DROP TABLE IF EXISTS ratemix.impressions_monthly_{PERIOD};

CREATE TABLE IF NOT EXISTS ratemix.impressions_monthly_{PERIOD}(
partition_date date,
year integer,
month integer,
period varchar(90),
marketplace_id bigint,
currency_code varchar(50000),
device_type varchar(50000),
page_type varchar(50000),
page_layout varchar(50000),
placement_slot varchar(50000),
impression_index varchar(50000),
page_number varchar(50000),
dominant_gl_group varchar(50000),
no_of_source_ads varchar(50000),
country_of_origin varchar(36),
merchant_type varchar(36),
prime_type integer,
bid_bucket_usd varchar(50000),
impressions bigint,
clicks bigint,
cost_local numeric,
revenue numeric
);

CREATE INDEX IF NOT EXISTS IMPRESSIONS_MONTHLY_{PERIOD}_IDX1 ON ratemix.impressions_monthly_{PERIOD}(marketplace_id);

CREATE INDEX IF NOT EXISTS IMPRESSIONS_MONTHLY_{PERIOD}_IDX2 ON ratemix.impressions_monthly_{PERIOD}(page_type);

CREATE INDEX IF NOT EXISTS IMPRESSIONS_MONTHLY_{PERIOD}_IDX3 ON ratemix.impressions_monthly_{PERIOD}(partition_date);