CREATE TABLE IF NOT EXISTS ratemix.traffic_monthly(
	partition_date date,
	month integer,
	year integer,
	period varchar(90),
	marketplace_id bigint,
	device varchar(50000),
	page_type varchar(50000),
	tq_valid_placement varchar(1000),
	page_number varchar(1000),
	page_layout varchar(1000),
	page_views bigint,
	filled_page_requests bigint,
	valid_impression bigint,
	total_impression bigint,
	total_revenue numeric,
	valid_revenue numeric,
	total_clicks bigint
) PARTITION BY RANGE (partition_date);


DROP TABLE IF EXISTS ratemix.traffic_monthly_{PERIOD};


CREATE TABLE IF NOT EXISTS ratemix.traffic_monthly_{PERIOD}(
	partition_date date,
	month integer,
	year integer,
	period varchar(90),
	marketplace_id bigint,
	device varchar(50000),
	page_type varchar(50000),
	tq_valid_placement varchar(1000),
	page_number varchar(1000),
	page_layout varchar(1000),
	page_views bigint,
	filled_page_requests bigint,
	valid_impression bigint,
	total_impression bigint,
	total_revenue numeric,
	valid_revenue numeric,
	total_clicks bigint
);

CREATE INDEX IF NOT EXISTS TRAFFIC_AGG1_{PERIOD}_IDX1 ON ratemix.traffic_monthly_{PERIOD}(marketplace_id);

CREATE INDEX IF NOT EXISTS TRAFFIC_AGG1_{PERIOD}_IDX2 ON ratemix.traffic_monthly_{PERIOD}(page_type);

CREATE INDEX IF NOT EXISTS TRAFFIC_AGG1_{PERIOD}_IDX3 ON ratemix.traffic_monthly_{PERIOD}(partition_date);