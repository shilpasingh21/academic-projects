CREATE TABLE IF NOT EXISTS ratemix.traffic_aggregate(
	partition_date date,
	year integer,
	month integer,
	period varchar(90),
	device varchar(50000),
	page_layout varchar(1000),
	page_type varchar(50000),
	page_number varchar(1000),
	marketplace_id bigint,
	page_views bigint,
	filled_page_requests bigint,
	valid_impression bigint,
	total_impression bigint
) PARTITION BY RANGE (partition_date);


DROP TABLE IF EXISTS ratemix.traffic_aggregate_{PERIOD};

CREATE TABLE IF NOT EXISTS ratemix.traffic_aggregate_{PERIOD}(
	partition_date date,
	year integer,
	month integer,
	period varchar(90),
	device varchar(50000),
	page_layout varchar(1000),
	page_type varchar(50000),
	page_number varchar(1000),
	marketplace_id bigint,
	page_views bigint,
	filled_page_requests bigint,
	valid_impression bigint,
	total_impression bigint);


CREATE INDEX IF NOT EXISTS TRAFFIC_AGG2_{PERIOD}_IDX1 ON ratemix.traffic_aggregate_{PERIOD}(marketplace_id);

CREATE INDEX IF NOT EXISTS TRAFFIC_AGG2_{PERIOD}_IDX2 ON ratemix.traffic_aggregate_{PERIOD}(page_type);

CREATE INDEX IF NOT EXISTS TRAFFIC_AGG2_{PERIOD}_IDX3 ON ratemix.traffic_aggregate_{PERIOD}(partition_date);