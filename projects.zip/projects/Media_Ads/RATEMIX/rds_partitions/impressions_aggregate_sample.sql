-- load the table

-- alter table add partition-date colun

-- update partition_date colmn with teh valiue

-- create indexex on the temp table

create index page_type_idx on fact_sp_perf_rate_mix_mtly(page_type)

create index marketplace_idx on fact_sp_perf_rate_mix_mtly(marketplace_id)

alter table fact_sp_perf_rate_mix_mtly add constraint fact_sp_perf_rate_mix_mtly_pcheck check
(partition_date = DATE('2021-08-01'))


	-------------------

create index page_type_idx on ratemix.impressions_aggregate(page_type)

create index marketplace_idx on ratemix.impressions_aggregate(marketplace_id)


CREATE TABLE ratemix.impressions_aggregate(
partition_date date,
year integer,
month integer,
period varchar(90),
device_type varchar(50000),
page_layout varchar(50000),
page_type varchar(50000),
placement_slot varchar(50000),
marketplace_id bigint,
impressions numeric,
revenue numeric,
page_request_with_ads numeric
) PARTITION BY RANGE (partition_date) 

CREATE INDEX ON ratemix.impressions_aggregate (marketplace_id);

CREATE INDEX ON ratemix.impressions_aggregate (page_type);

CREATE INDEX ON ratemix.impressions_aggregate (partition_date);


CREATE TABLE ratemix.impressions_aggregate_202201 PARTITION OF ratemix.impressions_aggregate 
FOR VALUES FROM ('2021-08-01') TO ('2021-08-02') PARTITION BY LIST(marketplace_id);

CREATE TABLE ratemix.impressions_aggregate_202202 PARTITION OF ratemix.impressions_aggregate 
FOR VALUES FROM ('2021-08-02') TO ('2021-08-03') PARTITION BY LIST(marketplace_id);

CREATE TABLE ratemix.impressions_aggregate_202203 PARTITION OF ratemix.impressions_aggregate 
FOR VALUES FROM ('2021-08-03') TO ('2021-08-04') PARTITION BY LIST(marketplace_id);

ALTER TABLE ratemix.impressions_aggregate ATTACH PARTITION fact_sp_perf_rate_mix_mtly 
FOR VALUES FROM ('2021-08-01') TO ('2021-08-02');

ALTER TABLE ratemix.impressions_aggregate DETACH partition ratemix.impressions_aggregate_temp_2





-- For reload

-- Detach partition if already exts

-- attach new partition

-- check if the partition is therre:

    select * from information_schema.tables where lower(table_schema)='ratemix'
		and lower(table_name)='impressions_aggregate_202204'
   
   if yes, detach it and attach temp again

   If no, create the partition and attach the temp again


   --ETL stesp:

   1. replace period in the sql file
   2. exceute the sql file
   3. load data frame in the table
   4. attach partition
   5 check the query plans











