from datetime import datetime

import pytz
from airflow import DAG
from airflow.sensors.base import BaseSensorOperator

from SpektrOrchestratorPlugins.dag_generator.task_lineage.operator_factory import get_operator
from SpektrOrchestratorPlugins.handlers.base_handlers import BaseHandlers
from SpektrOrchestratorPlugins.utils.package_utils import import_package
from SpektrOrchestratorPlugins import constants
from SpektrOrchestratorPlugins.exceptions import InvalidDagJsonException


class TaskLineageGenerator:
    """
    This class is responsible for generating Tasks Lineage for a DAG from JSON
    """

    def __init__(self, dag_json, dag_id, dag: DAG):
        self.operators = {}
        self.dag_json = dag_json
        self.dag_id = dag_id
        self.dag = dag

    def generate_task_lineage(self):
        self._set_dag_mandatory_params(self.dag, self.dag_json)
        tasks = self.dag_json['tasks']
        for task in tasks:
            task_id = task["task_id"]
            operator_name = task["operator_type"]

            subdag = None
            if operator_name.endswith("SubDagOperator"):
                subdag = self._create_subdag(task, task_id)

            operator = self._create_task(task, self.dag, subdag=subdag)
            self.operators[task_id] = operator

        for task in tasks:
            for dependency in task["dependencies"]:
                if dependency:
                    operator = self.operators[task["task_id"]]
                    upstream_operator = self.operators[dependency]
                    operator.set_upstream(upstream_operator)

    def _create_subdag(self, subdag_json, parent_task_id):
        operators_map = {}
        dependency_map = {}
        dag_subdag = DAG(
            dag_id=f"{self.dag_id}.{parent_task_id}"
        )
        self._set_dag_mandatory_params(dag_subdag, subdag_json)
        dag_subdag.is_subdag = True
        # Create All Sub Tasks
        tasks = subdag_json['tasks']
        for task in tasks:
            operator = self._create_task(task, dag_subdag)
            task_id = task["task_id"]
            dependency_map[task_id] = task['dependencies']
            operators_map[task_id] = operator

        for task_id, operator in operators_map.items():
            for dependency in dependency_map[task_id]:
                operator.set_upstream(operators_map[dependency])
        return dag_subdag

    def get_default_args(self):
        """
        Get default args for dag from dag_json. default args are passed to all operator.
        https://airflow.apache.org/docs/apache-airflow/stable/tutorial.html#default-arguments
        Returns:
            dict: default args
        """
        default_args = self.dag_json["default_args"] if "default_args" in self.dag_json else {}
        return default_args

    def get_start_date(self):
        """
        Get start date from DAG Json. Allowed formats = "%Y-%m-%d" or "%Y-%m-%dT%H-%M"
        Returns:
            datetime: start_date datetime object
        """
        if "start_date" in self.dag_json:
            start_date = self.dag_json["start_date"]
            if len(start_date) == 10:
                return pytz.utc.localize(datetime.strptime(start_date, constants.JSON_INPUT_DATE_FORMAT_GENERIC))
            elif len(start_date) == 16:
                return pytz.utc.localize(datetime.strptime(start_date, constants.JSON_INPUT_DATE_FORMAT_HOURLY))
            else:
                raise InvalidDagJsonException(f"Invalid start_date: {start_date} format. "
                                              f"allowed formats are {constants.JSON_INPUT_DATE_FORMAT_GENERIC} "
                                              f"and for hourly only: {constants.JSON_INPUT_DATE_FORMAT_HOURLY}")
        else:
            raise InvalidDagJsonException(f"start_date is required field.")

    def get_end_date(self):
        """
        Get end date from DAG Json. Allowed formats = "yyyy-mm-ddTHH:MM" or "yyyy-mm-dd"
        Returns:
            datetime: end_date datetime object if present else none
        """
        if "end_date" in self.dag_json:
            end_date = self.dag_json["end_date"]
            if len(end_date) == 10:
                return pytz.utc.localize(datetime.strptime(end_date, constants.JSON_INPUT_DATE_FORMAT_GENERIC))
            elif len(end_date) == 16:
                return pytz.utc.localize(datetime.strptime(end_date, constants.JSON_INPUT_DATE_FORMAT_HOURLY))
            else:
                raise InvalidDagJsonException(f"Invalid end_date format. "
                                              f"allowed formats are {constants.JSON_INPUT_DATE_FORMAT_GENERIC} "
                                              f"and for hourly only: {constants.JSON_INPUT_DATE_FORMAT_HOURLY}")
        else:
            return None

    def get_schedule_interval(self):
        """
        Get schedule interval from dag_json (mandatory field)
        Returns:
            str: Schedule interval cron or one of @hourly/@daily/@weekly etc
        """
        if "scheduled_interval" in self.dag_json:
            return self.dag_json["scheduled_interval"]
        raise InvalidDagJsonException(f"Schedule Interval is required field.")

    def _set_dag_mandatory_params(self, dag: DAG, dag_json):
        """
        Set DAG Params from DAG Json (For subdag it will be sub dag json)
        Args:
            dag: dag to be set
            dag_json: dag_json (For subdag it will be sub dag json)
        """
        dag.start_date = self.get_start_date()
        if self.get_end_date():
            dag.end_date = self.get_end_date()

        if "handlers_class" in dag_json:
            handlers = import_package(dag_json["handlers_class"])()
        else:
            handlers = BaseHandlers()

        dag.depends_on_past = self.dag_json.get("depends_on_past", "false").lower() == "true"
        dag.catchup = self.dag_json.get("catchup", "true").lower() == "true"
        dag.workflow_mode = self.dag_json.get("workflow_mode", constants.DEFAULT_WORKFLOW_MODE)
        dag.is_paused_upon_creation = self.dag_json.get("is_paused_upon_creation", "false").lower() == "true"
        dag.max_active_runs = int(self.dag_json.get("max_active_run", constants.DEFAULT_MAX_ACTIVE_RUNS))
        dag.on_failure_callback = handlers.dag_failure_handler
        dag.on_success_callback = handlers.dag_success_handler
        dag.default_args = self.get_default_args()
        dag.schedule_interval = self.get_schedule_interval()
        dag.dagrun_timeout = constants.DEFAULT_DAG_TIMEOUT

    def _create_task(self, task, dag, subdag=None):
        # task_id and operator_module are mandatory fields
        self._validate_task(task)
        task_id = task["task_id"]
        operator_name = task["operator_type"]
        retries = int(task["retries"]) if "retries" in task else constants.DEFAULT_RETRIES
        execution_timeout = int(task["execution_timeout"]) if "execution_timeout" in task \
            else constants.DEFAULT_TASK_TIMEOUT
        sensor_timeout = int(task["timeout"]) if "timeout" in task else constants.DEFAULT_SENSOR_TIMEOUT
        # If separate handler_class is given for task, use it else use dags handlers_class or BaseHandler by default
        if "handlers_class" in task:
            handlers = import_package(task["handlers_class"])()
        elif "handlers_class" in self.dag_json:
            handlers = import_package(self.dag_json["handlers_class"])()
        else:
            handlers = BaseHandlers()

        params = {}
        if "params" in task:
            params = task["params"]

        extra_args = {}
        if operator_name.endswith("PythonOperator"):
            if "python_callable" in task:
                extra_args["python_callable"] = import_package(task["python_callable"])

        if subdag:
            extra_args["subdag"] = subdag

        operator = get_operator(operator_module=operator_name, task_id=task_id, retries=retries,
                                execution_timeout=execution_timeout, params=params, handlers=handlers, dag=dag,
                                args=extra_args)
        if isinstance(operator, BaseSensorOperator):
            operator.timeout = sensor_timeout
        return operator

    @classmethod
    def _validate_task(cls, task):
        if 'task_id' not in task or 'operator_type' not in task:
            raise InvalidDagJsonException(f" Mandatory fields task_id or operator_type missing from task: {task}")